@extends('frontend.layouts.app')
@section('description')
<meta name="description" content="" />
@endsection
@section('keywords')
<meta name="keywords" content="" />
@endsection
@section('title', 'Page de description EMF')
@section('content')
<section class="page-header page-header-modern page-header-background page-header-background-pattern page-header-background-sm overlay overlay-color-dark overlay-show overlay-op-5" style="background-image: url(img/patterns/wild_oliva.png);">
					<div class="container">
						<div class="row">
							<div class="col-md-12 align-self-center p-static order-2 text-center">
								<h1>{{__('parteners.structure')}}</h1>
							</div>
							<div class="col-md-12 align-self-center order-1">
								<ul class="breadcrumb breadcrumb-light d-block text-center">
									<li><a href="{{route('home')}}"> {{__('nav.home')}}</a></li>
									<li><a href="{{route('partner')}}">{{__('nav.parteners')}}</a></li>
									<li class="active">{{__('parteners.structure')}}</li>
								</ul>
							</div>
						</div>
					</div>
				</section>
<div class="container">
	<div class="row py-4">
						<div class="col-lg-8">

							<div class="overflow-hidden mb-1">
								<h1 class="font-weight-normal text-7 mt-2 mb-0 appear-animation" data-appear-animation="maskUp" data-appear-animation-delay="200"><strong class="font-weight-extra-bold">{{__('parteners.structure')}}</strong></h1>
							</div>
							<div class="overflow-hidden mb-4 pb-3">
								<p class="mb-0 appear-animation" data-appear-animation="maskUp" data-appear-animation-delay="400">{{__('partener-desc.title')}}</p>
							</div>
							<div class="row">
								<div class="col-lg-12">
									<img src="{{ asset('img/logo3.jpg') }}" class="img-emf-description" alt="">
									<p>{{__('partener-desc.texte')}}</p>
									<div>
										<h2>{{__('partener-desc.title-2')}}</h2>
										<ul>
											<li>{{__('partener-desc.liste-1')}}</li>
											<li>{{__('partener-desc.liste-2')}}</li>
											<li>{{__('partener-desc.liste-3')}}</li>
											<li>{{__('partener-desc.liste-4')}}</li>
											<li>{{__('partener-desc.liste-5')}}</li>
											<li>{{__('partener-desc.liste-6')}}</li>
										</ul>
									</div>
									<h2>{{__('partener-desc.title-3')}}</h2>
									<ul>
										<li>{{__('partener-desc.liste-7')}}</li>
										<li>{{__('partener-desc.liste-8')}}</li>
										<li>{{__('partener-desc.liste-9')}}</li>
										<li>{{__('partener-desc.liste-10')}}</li>
									</ul>
								</div>
							</div>

						</div>
						<!--<div class="col-lg-4">

							<div class="appear-animation" data-appear-animation="fadeIn" data-appear-animation-delay="800">
								<h4 class="mt-2 mb-1"><strong>Douala</strong></h4>
								<ul class="list list-icons list-icons-style-2 mt-2">
									<li><i class="fas fa-map-marker-alt top-6"></i> <strong class="text-dark">Akwa</strong> Boulevard de la liberté </li>
									<li><i class="fas fa-map-marker-alt top-6"></i> <strong class="text-dark">Bependa</strong> Camtel</li>
									<li><i class="fas fa-map-marker-alt top-6"></i> <strong class="text-dark">Bonanjo</strong> GICAM</li>
								</ul>
							</div>

							<div class="appear-animation" data-appear-animation="fadeIn" data-appear-animation-delay="800">
								<h4 class="mt-2 mb-1"><strong>Yaoundé</strong></h4>
								<ul class="list list-icons list-icons-style-2 mt-2">
									<li><i class="fas fa-map-marker-alt top-6"></i> <strong class="text-dark">Biyem-Assi</strong> Carrefour</li>
									<li><i class="fas fa-map-marker-alt top-6"></i> <strong class="text-dark">Mvan</strong>Santa Lucia</li>
									<li><i class="fas fa-map-marker-alt top-6"></i> <strong class="text-dark">Tsinga</strong> Ancienne mairie</li>
								</ul>
							</div>	

						</div>-->

					</div>
				</div>

@endsection