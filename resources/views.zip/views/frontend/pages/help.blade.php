@extends('frontend.layouts.app')
@section('description')
<meta name="description" content="" />
@endsection
@section('keywords')
<meta name="keywords" content="" />
@endsection
@section('title', 'Aide Utilisateur')
@section('content')

<section class="page-header page-header-modern page-header-background page-header-background-pattern page-header-background-sm overlay overlay-color-dark overlay-show overlay-op-5" style="background-image: url(img/patterns/wild_oliva.png);">
					<div class="container">
						<div class="row">
							<div class="col-md-12 align-self-center p-static order-2 text-center">
								<h1> {{__('nav.title')}} <strong>{{__('nav.title-2')}}</strong></h1>
							</div>
							<div class="col-md-12 align-self-center order-1">
								<ul class="breadcrumb breadcrumb-light d-block text-center">
									<li><a href="{{route('home')}}">{{__('nav.home')}}</a></li>
									<li><a href="#"> {{__('nav.about-us')}}</a></li>
									<li class="active">{{__('nav.about-us-1')}}</li>
								</ul>
							</div>
						</div>
					</div>
				</section>
	<div class="container py-2">
		<div class="row mt-5">
						<div class="col">
							<div class="row">
								<div class="col-lg-3">
									<div class="tabs tabs-vertical tabs-right tabs-navigation tabs-navigation-simple">
										<ul class="nav nav-tabs col-sm-3">
											<li class="nav-item active">
												<a class="nav-link" href="#tabsNavigationVertSimple1" data-toggle="tab">{{__('help.cash-deposit')}}</a>
											</li>
											<li class="nav-item">
												<a class="nav-link" href="#tabsNavigationVertSimple2" data-toggle="tab">{{__('help.cash-withdrawal')}}</a>
											</li>
											<li class="nav-item">
												<a class="nav-link" href="#tabsNavigationVertSimple3" data-toggle="tab">{{__('help.cash-transfer')}}</a>
											</li>
											<li class="nav-item">
												<a class="nav-link" href="#tabsNavigationVertSimple5" data-toggle="tab">{{__('help.transaction-management')}}</a>
											</li>
											<li class="nav-item">
												<a class="nav-link" href="#tabsNavigationVertSimple4" data-toggle="tab">{{__('help.customer-setup')}}</a>
											</li>
										</ul>
									</div>
								</div>
								<div class="col-lg-9">
									<!--<div class="tab-pane tab-pane-navigation active" id="tabsNavigationVertSimple1">
										<h4>{{__('help.cash-deposit')}}</h4>
										@if(session('applocale')=="fr") 
											<iframe src="https://docs.google.com/presentation/d/e/2PACX-1vQTPa1iUPE9N9Wc7pj0w-D6rnWM6-jK6BVCbA1to_t6xFizDUWCtVHOd_IV1tu-mg/embed?start=false&loop=false&delayms=3000" frameborder="0" width="850" height="667" allowfullscreen="true" mozallowfullscreen="true" webkitallowfullscreen="true"></iframe>
										@else
											<iframe src="https://docs.google.com/presentation/d/e/2PACX-1vQjmZsnPzJG64Uza0Tt__kywv9UMCBF_KvfHj1MHjdstV576c_T7el-H6OG10EA-A/embed?start=false&loop=false&delayms=3000" frameborder="0" width="850" height="667" allowfullscreen="true" mozallowfullscreen="true" webkitallowfullscreen="true"></iframe></iframe>
										@endif
									</div>
									<div class="tab-pane tab-pane-navigation" id="tabsNavigationVertSimple2">
										<h4>{{__('help.cash-withdrawal')}}</h4>
										@if(session('applocale')=="fr") 
											<iframe src="https://docs.google.com/presentation/d/e/2PACX-1vRkiqk0kU4YmLNhYD-RhOzdMsFnnNGZ7tXnVQHvTCIjSDe-VHErNnnHRonLTZvy-Q/embed?start=false&loop=false&delayms=3000" frameborder="0" width="850" height="667" allowfullscreen="true" mozallowfullscreen="true" webkitallowfullscreen="true"></iframe>
										@else
											<iframe src="https://docs.google.com/presentation/d/e/2PACX-1vSz6zRoseGt6ZFIIATa5gonIaPLQhfb8LqFDeeuhVwYALcFwfUUmFhdlVByYFTWMw/embed?start=false&loop=false&delayms=3000" frameborder="0" width="850" height="667" allowfullscreen="true" mozallowfullscreen="true" webkitallowfullscreen="true"></iframe></iframe>
										@endif
									</div>
									<div class="tab-pane tab-pane-navigation" id="tabsNavigationVertSimple3">
										<h4>{{__('help.cash-transfer')}}</h4>
										@if(session('applocale')=="fr") 
											<iframe src="https://docs.google.com/presentation/d/e/2PACX-1vT0AE-oSNxwjTVkHjDOmDzQJb0MzO85hHZdIFXQGUWew6O9iHV_5ag_k8VToCstSw/embed?start=false&loop=false&delayms=3000" frameborder="0" width="850" height="667" allowfullscreen="true" mozallowfullscreen="true" webkitallowfullscreen="true"></iframe>
										@else
											<iframe src="https://docs.google.com/presentation/d/e/2PACX-1vQkEkZ2rw3gqmJwW9Ogx2g1P-JrwmKmaK36Jy_ZxTDfAEkGhCrtbPINMsyZjgieJA/embed?start=false&loop=false&delayms=3000" frameborder="0" width="850" height="667" allowfullscreen="true" mozallowfullscreen="true" webkitallowfullscreen="true"></iframe></iframe>
										@endif
									</div>
									<div class="tab-pane tab-pane-navigation" id="tabsNavigationVertSimple4">
										<h4>{{__('help.customer-setup')}}</h4>
										@if(session('applocale')=="fr") 
											<iframe src="https://docs.google.com/presentation/d/e/2PACX-1vR2ssXMAPAFSd3CsZvyO17W-k36sZIfsrwJK7Rd1anrR5_QLjTAPYxvHUuniG-N1A/embed?start=false&loop=false&delayms=3000" frameborder="0" width="850" height="667" allowfullscreen="true" mozallowfullscreen="true" webkitallowfullscreen="true"></iframe>
										@else
											<iframe src="https://docs.google.com/presentation/d/e/2PACX-1vT2ItntNjGBdm5KNRnZHTdP-xcPWVv6CvbROvHYJesfBO_N0RDQbmli5SY6K95kqg/embed?start=false&loop=false&delayms=3000" frameborder="0" width="850" height="667" allowfullscreen="true" mozallowfullscreen="true" webkitallowfullscreen="true"></iframe></iframe>
										@endif
									</div>
									<div class="tab-pane tab-pane-navigation" id="tabsNavigationVertSimple5">
										<h4>{{__('help.transaction-management')}}</h4>
										@if(session('applocale')=="fr") 
											<iframe src="https://docs.google.com/presentation/d/e/2PACX-1vSxJ1ac9sEcvqTN6yq6lXfIGLNzjn9mp8qXQ1kKBx9Ux4GPWMg18SF4ecazbzgWhw/embed?start=false&loop=false&delayms=3000" frameborder="0" width="850" height="667" allowfullscreen="true" mozallowfullscreen="true" webkitallowfullscreen="true"></iframe>
										@else
											<iframe src="https://docs.google.com/presentation/d/e/2PACX-1vTwM3YlzitJcs15GgKvfhyKRfqiNeTd36eOfnLSCd0DOuJI1eT9OWnU-f38ZdBCTQ/embed?start=false&loop=false&delayms=3000" frameborder="0" width="850" height="667" allowfullscreen="true" mozallowfullscreen="true" webkitallowfullscreen="true"></iframe></iframe>
										@endif
									</div>-->
									<div class="tab-pane tab-pane-navigation active" id="tabsNavigationVertSimple1">
										<h4>{{__('help.cash-deposit')}}</h4>
										<div class="row py-2">
											<h5>Avec MTN</h5>
											<div class="">
												<img src="{{ asset('img/aide/web/depot/2.png') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p>Dans Becon’bank, le dépôt d’argent permet de mettre de l’argent dans votre compte bancaire à travers votre compte mobile money pour effectuer un dépôt, veuillez suivre les étapes suivantes :</p>
												<p>1- cliquer sur « Opérations », après sélectionner « Dépôt d’argent »</p>
												<p>Ou vous pouvez cliquer sur :</p>
												<p>2- « dépôt d’argent »</p>
											</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/depot/3.png') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p>3- Remplir les champs, ensuite cliquer sur « Valider »</p>
												<p>4- Vous recevrez un message de votre opérateur mobile pour confirmer l’opération</p>
											</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/depot/4.png') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p>5- Vous recevrez un message de votre Opérateur téléphonique dans votre téléphone</p>
												<p>6- et un mail de Becon’Bank</p>
												<p>7- La transaction passe au statut « confirmed »</p>
											</div>
										</div>
										<div class="row py-2">
											<h5>Avec Orange</h5>
											<div class="">
												<img src="{{ asset('img/aide/web/depot/2.png') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p>Dans Becon’bank, le dépôt d’argent permet de mettre de l’argent dans votre compte bancaire à travers votre compte mobile money pour effectuer un dépôt, veuillez suivre les étapes suivantes :</p>
												<p>1- cliquer sur « Opérations », après sélectionner « Dépôt d’argent »</p>
												<p>Ou vous pouvez cliquer sur :</p>
												<p>2- « dépôt d’argent »</p>
											</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/depot/5.png') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p>3- Remplir les champs, ensuite cliquer sur « Valider »</p>
												<p>Taper #150*4*4# sur votre téléphone pour générer le code marchand</p>
												<p>4- Code marchand (code de paiement)</p>
												<p>Le code de paiement est un code de sécurité mis par Orange Cameroun qui permet de sécuriser les retraits d’argent</p>
											</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/depot/6.png') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p>5- Remplir les champs et cliquer sur « confirm »</p>
											</div>
										</div>
										<!--<div class="row py-2">
											<div class="col-lg-7">
												<img src="{{ asset('img/aide/web/depot/7.png') }}" style="width: 100%;">
											</div>
											<div class="col-lg-5" style=" ">
												<p>6- Vous recevrez un message de votre Opérateur téléphonique dans votre téléphone</p>
												<p>7- et un mail de Becon’Bank</p>
												<p>8- La transaction passe au statut « confirmed »</p>
											</div>
										</div>-->
									</div>
									<div class="tab-pane tab-pane-navigation" id="tabsNavigationVertSimple2">
										<h4>Retrait d'argent</h4>
										<!--<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/retrait/2.png') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p>Il existe deux types de retrait :</p>
												<ul>
													<li>Retrait d’argent vers mon numéro de téléphone</li>
													<li>Retrait d’argent vers un autre numéro de téléphone</li>
												</ul>
											</div>
										</div>-->
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/retrait/3.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p>Retrait d’argent vers mon numéro de téléphone vous permet de retirer de l’argent de votre compte bancaire pour votre compte mobile money</p>
												<p>Pour effectuer un  Retrait d’argent vers mon numéro de téléphone vous avez 02 possibilités</p>
												<p><u>1ère possibilité :</u></p>
												<p>1- cliquer sur « Opérations »</p>
												<p>2- après sélectionner « Retrait d’argent »</p>
												<p><u>2ème possibilité :</u></p>
												<p>Ou vous pouvez cliquer sur:</p>
												<p>1- « Retrait d’argent »</p>
												<p>2- Ensuite sur « Retrait vers mon numéro de téléphone »</p>
											</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/retrait/4.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p>5- Remplir les champs</p>
												<p>Client: votre nom complet</p>
												<p>Choix du compte: vous devez choisir l’un de vos compte avec lequel vous souhaitez effectuer la transaction</p>
												<p>Choix de l’opérateur: vous devez choisir entre  l’opérateur Orange et MTN</p>
												<p>Téléphone: votre numéro de téléphone s’affiche automatiquement en fonction du choix de l’opérateur et ne peut pas être modifier</p>
												<p>Montant à retirer code secret</p>
												<p>6- cliquer sur « valider »</p>
												<p>7- L’opération passe au statut « Unconfirmed » en attendant la validation de l’EMF/Banque</p>
											</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/retrait/5.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p>Retrait d’argent vers un autre numéro de téléphone vous de retirer de l’argent de votre compte bancaire vers le compte mobile money d’un de vos proches.</p>
												<p>Pour effectuer un  Retrait d’argent vers un autre numéro de téléphone vous avez 02 possibilités</p>
												<p><u>1ère possibilité :</u></p>
												<p>1- cliquer sur « Opérations »,</p>
												<p>2- après sélectionner « Retrait vers un autre numéro »</p>
												<p>2ème possibilité :</p>
												<p>Ou vous pouvez cliquer sur</p>
												<p>3- « Retrait d’argent »</p>
												<p>4- Ensuite sur « Retrait vers un autre numéro de téléphone »</p>
											</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/retrait/6.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p>5- Remplir les champs</p>
												<p>Client: votre nom complet</p>
												<p>Choix du compte: vous devez choisir l’un de vos compte avec lequel vous souhaitez effectuer la transaction</p>
												<p>Choix de l’opérateur: vous devez choisir entre  l’opérateur Orange et MTN</p>
												<p>Téléphone: numéro de téléphone vers lequel vous souhaitez envoyer de l’argent</p>
												<P>Nom Récipiendaire: nom de votre bénéficiaire</P>
												<p>Montant à retirer: montant que vous souhaitez retirer</p>
												<p><strong>Code secret</strong></p>
												<p>6- cliquer sur « valider »</p>
												<p>7- L’opération passe au statut « Unconfirmed » en attendant la validation de l’EMF/Banque</p>
											</div>
										</div>
									</div>
									<div class="tab-pane tab-pane-navigation " id="tabsNavigationVertSimple3">
										<h4>Transfert d'argent</h4>
										<!--<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/Transfert/2.png') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p></p>
											</div>
										</div>-->
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/Transfert/3.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p>Il existe deux types de transfert sur Becon’Bank :</p>
												<ul>
													<li>Transfert vers un autre compte</li>
													<li>Transfert pour retrait en agence</li>
												</ul>
											</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/Transfert/4.png') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p>La fonctionnalité « transfert vers un compte » permet d’effectuer un transfert d’argent de votre compte bancaire vers un autre compte bancaire.</p>
												<p><strong><u>NB:</u> Les comptes bancaires doivent être domiciliés dans le même établissement financier</strong></p>
												<p>Pour transférer de l’argent vers un autre compte, vous avez 02 possibilité :</p>
												<p>1ère possibilité :</p>
												<p>1- cliquer sur « Opérations »,</p>
												<p>2- après sélectionner « Transfert vers un compte  »</p>
												<p>2ème possibilité :</p>
												<p>3- cliquer sur « Transferts »,</p>
												<p>4- Ensuite cliquer sur « Transfert vers un compte  »</p>
											</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/Transfert/5.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p>5- remplir les champs</p>
												<p>Numéro de compte: vous devez choisir l’un de vos compte avec lequel vous souhaitez effectuer la transaction</p>
												<p>Compte receveur: numéro de compte bancaire dans lequel vous voulez transférer de l’argent</p>
												<p>Nom récipiendaire: le nom complet du propriétaire du compte bénéficiaire</p>
												<p>Montant à transférer Code secret: votre code secret</p>
												<p>6- cliquer sur « valider le transfert »</p>
												<p>7- l’opération passe au statut « unconfirmed » pour validation par l’EMF.</p>
											</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/Transfert/6.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p>La fonctionnalité « Retrait en agence » permet d’envoyer de l’argent à une personne qui n’a pas soit un compte bancaire soit un compte domicilié dans votre établissement financier</p>
												<p>Pour effectuer un transfert pour retrait en agence, vous avez 02 possibilités :</p>
												<p><u>1ère possibilité :</u></p>
												<p>1- cliquer sur « Opérations »,</p>
												<p>2- après sélectionner « Retrait en agence »</p>
												<p>2ème possibilité :</p>
												<p>3- cliquer sur « Transferts »,</p>
												<p>4- Ensuite cliquer sur « Pour retrait en agence »</p>
											</div>
										</div>
										<!--<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/Transfert/7.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p>5- remplir les champs</p>
												<p>Numéro de bordereau: à communiquer à votre bénéficiaire</p>
												<p>Choix du compte: choisir l’un de vos comptes avec lequel vous souhaitez effectuer la transaction</p>
												<p>Nom(s) et prénom(s): le nom complet de la personne à qui vous envoyez de l’argent</p>
												<p>Numéro téléphone: numéro de téléphone du destinataire</p>
												<p>Montant : le montant que vous souhaitez envoyer</p>
												<p>Code secret: votre code secret à communiquer à votre bénéficiaire</p>
												<p>6- cliquer sur « valider le transfert »</p>
												<p>7- l’opération passe au statut « unconfirmed » pour validation par l’EMF.</p>
											</div>
										</div>-->
									</div>
									<div class="tab-pane tab-pane-navigation" id="tabsNavigationVertSimple5">
										<h4>Transaction</h4>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/transaction/2.png') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p>La fonctionnalité Gestion transactions est subdivisée en 2 éléments</p>
												<ul>
													<li>Transactions en cours : affiche l’ensemble des transactions en attente de validation par l’Administration</li>
													<li>Historique : affiche l’ensemble de vos transactions (confirmées, validées, payées)</li>
												</ul>
											</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/transaction/3.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p>La fonctionnalité « transactions en cours » permet de visualiser les opérations qui doivent être confirmées par l’Administrateur.</p>
												<p>Pour accéder à cette fonctionnalité, veuillez suivre les étapes suivantes :</p>
												<p>1- cliquer sur « Gestion des Transaction».</p>
												<p>2- cliquer sur « transactions en cours ».</p>
												<p>3- Vous avez accès aux transactions en attente</p>
											</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/transaction/4.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p>La fonctionnalité « historique » permet de visualiser l’ensemble de toutes les transactions du client (dépôt, retrait, transfert, validées, confirmées, payées).</p>
												<p>Pour accéder à cette fonctionnalité, veuillez suivre les étapes suivantes :</p>
												<p>1- cliquer sur « Gestion des Transaction».</p>
												<p>2- cliquer sur « Historique ».</p>
												<p>3- Vous avez accès à l’historique</p>
											</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/transaction/5.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p>Vous avez la possibilité de visualiser vos transactions en fonction de vos différents comptes</p>
												<p>1- aller dans « tableau de bord »</p>
												<p>2- sélectionner un compte</p>
											</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/transaction/6.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p>3- vous avez le solde et les transactions récentes du compte sélectionné</p>
											</div>
										</div>
									</div>
									<div class="tab-pane tab-pane-navigation" id="tabsNavigationVertSimple4">
										<h4>Parametrage du Client</h4>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/profil/1.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p>Après création du client par l’EMF/Banque, le client reçoit un email de confirmation</p>
												<p>1- Copier votre mot de passe par défaut et retenez votre code secret par défaut</p>
												<p>2- cliquez sur « cliquer ici pour vérifier votre compte »</p>
												<p>Vous êtes redirigez vers la page de connexion</p>
											</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/profil/2.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p>Page de connexion</p>
												<p>Veuillez entrer votre email ou votre numéro de téléphone et votre mot de passe</p>
												<p>3- Cliquez sur « se connecter »</p>
											</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/profil/3.png') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p></p>
											</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/profil/4.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<ul>
													<li>Tableau de bord: affiche le solde et les transactions récentes</li>
													<li>Opérations: permet de faire les transactions (dépôt, retrait, transfert)</li>
													<li>Gestion des transactions: permet de visualiser l’ensemble des transactions effectuées dans son compte</li>
													<li>Dépôt d’argent: permet d’effectuer un dépôt du compte mobile money vers le compte bancaire</li>
													<li>Retrait d’argent: permet d’effectuer les retraits d’argent du compte bancaire vers le compte mobile money</li>
													<li>Transfert: permet d’effectuer les transferts vers un autre compte bancaire et les retraits en agence.</li>
												</ul>
											</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/profil/5.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p></p>
											</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/profil/6.png') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p>Pour changer de langue, veuillez suivre les étapes suivantes :</p>
												<p>1- cliquer sur le symbole</p>
												<p>2- sélectionner la langue de votre choix</p>
											</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/profil/7.png') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p>Pour « visualiser le Profil », veuillez suivre les étapes suivantes :</p>
												<p>1- Cliquer sur votre nom</p>
												<p>2- Cliquer sur « profil »</p>
												<p>Vous avez accès à votre « profil »</p>
											</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/profil/8.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p></p>
											</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/profil/9.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p></p>
											</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/profil/10.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p></p>
											</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/profil/11.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p>Pour changer le mot de passe de votre compte, veuillez suivre les étapes suivantes :</p>
												<p>1- Cliquer sur votre nom</p>
												<p>2- Cliquer sur « Changer Mot De Passe »</p>
												<p>3- renseigner les champs et cliquer sur « Soumettre »</p>
											</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/profil/12.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p>Le code secret permet de sécuriser les transactions.</p>
												<p>Pour changer le code secret de votre compte, veuillez suivre les étapes suivantes :</p>
												<p>1- Cliquer sur votre nom</p>
												<p>2- Cliquer sur « Changer Code Secret »</p>
												<p>3- renseigner les champs et cliquer sur « Soumettre »</p>
											</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/profil/12.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p>Pour « se déconnecter », veuillez suivre les étapes suivantes :</p>
												<p>1- Cliquer sur votre nom</p>
												<p>2- Cliquer sur « Déconnexion »</p>
												<p>3- vous êtes redirigés vers la page d’accueil</p>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
	</div>
@endsection