@extends('frontend.layouts.app')
@section('description')
    <meta name="description" content="" />
@endsection
@section('keywords')
    <meta name="keywords" content="" />
@endsection
@section('title', 'Page de description EMF')
@section('content')
    <section class="page-header page-header-modern page-header-background page-header-background-pattern page-header-background-sm overlay overlay-color-dark overlay-show overlay-op-5" style="background-image: url(img/patterns/wild_oliva.png);">
        <div class="container">
            <div class="row">
                <div class="col-md-12 align-self-center p-static order-2 text-center">
                    <h1>{{__('nav.privacy-policy')}}</h1>
                </div>
                <div class="col-md-12 align-self-center order-1">
                    <ul class="breadcrumb breadcrumb-light d-block text-center">
                        <li><a href="{{route('home')}}"> {{__('nav.home')}}</a></li>
                        <li><a href="{{route('privacy')}}">{{__('privacy.entete')}}</a></li>
                        <li class="active">{{__('nav.privacy-policy')}}</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <div class="container">
        <div class="row">
            <div>
                <h1 class="py-4">{{__('privacy.title')}}</h1>
            </div>
            <div>
                <h4 style="color: #833b0b">{{__('privacy.article-1')}}</h4>
                <p>{{__('privacy.article-1-desc')}}</p>
                <p>{{__('privacy.article-1-desc-2')}}</p><br>
            </div>
            <div>
                <h4 style="color: #833b0b">{{__('privacy.article-2')}}</h4>
                <p>{{__('privacy.article-2-desc')}}</p>
                <p>{{__('privacy.desc-2')}}</p>
                <p><strong>{{__('privacy.donnée-1')}}</strong>{{__('privacy.donnée-1-desc')}}</p>
                <p><strong>{{__('privacy.donnée-2')}}</strong>{{__('privacy.donnée-2-desc')}}</p>
                <p><strong>{{__('privacy.donnée-3')}}</strong>{{__('privacy.donnée-3-desc')}}</p>
                <p><strong>{{__('privacy.donnée-4')}}</strong>{{__('privacy.donnée-4-desc')}}</p>
                <p><strong>{{__('privacy.donnée-5')}}</strong>{{__('privacy.donnée-5-desc')}}</p>
                <p>{{__('privacy.desc-3')}}</p><br>
            </div>
            <div>
                <h4 style="color: #833b0b">{{__('privacy.article-3')}}</h4>
                <p>{{__('privacy.article-3-desc')}}</p><br>
            </div>
            <div>
                <h4 style="color: #833b0b">{{__('privacy.article-4')}}</h4>
                <p>{{__('privacy.article-4-desc')}}</p>
                <p>{{__('privacy.cas-1')}}</p>
                <p>{{__('privacy.cas-2')}}</p>
                <p>{{__('privacy.cas-3')}}</p>
                <p>{{__('privacy.cas-4')}}</p>
                <p>{{__('privacy.cas-5')}}</p><br>
            </div>
            <div>
                <h4 style="color: #833b0b">{{__('privacy.article-5')}}</h4>
                <p>{{__('privacy.article-5-desc')}}</p>
                <p>{{__('privacy.mesure-1')}}</p>
                <p>{{__('privacy.mesure-2')}}</p>
                <p>{{__('privacy.mesure-3')}}</p>
                <p>{{__('privacy.mesure-4')}}</p><br>
            </div>
            <div>
                <h4 style="color: #833b0b">{{__('privacy.article-6')}}</h4>
                <p>{{__('privacy.article-6-desc')}}</p>
                <p>{{__('privacy.article-6-desc-1')}}</p>
                <p>{{__('privacy.article-6-desc-2')}}</p><br>
            </div>
            <div>
                <h4 style="color: #833b0b">{{__('privacy.article-7')}}</h4>
                <h5>{{__('privacy.point-1')}}</h5>
                <p>{{__('privacy.point-1-desc')}}</p>
                <h5>{{__('privacy.point-2')}}</h5>
                <p>{{__('privacy.point-2-desc')}}</p>
                <p>{{__('privacy.article-7-desc')}}</p>
            </div>
        </div>
    </div>

@endsection