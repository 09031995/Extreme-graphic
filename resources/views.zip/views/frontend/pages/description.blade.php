@extends('frontend.layouts.app')
@section('description')
<meta name="description" content="" />
@endsection
@section('keywords')
<meta name="keywords" content="" />
@endsection
@section('title', 'Aide Utilisateur')
@section('content')

    <section class="page-header page-header-modern page-header-background page-header-background-pattern page-header-background-sm overlay overlay-color-dark overlay-show overlay-op-5" style="background-image: url(img/patterns/wild_oliva.png);">
        <div class="container">
            <div class="row">
                <div class="col-md-12 align-self-center p-static order-2 text-center">
                    <h1> {{__('nav.title')}} <strong>{{__('nav.title-2')}}</strong></h1>
                </div>
                <div class="col-md-12 align-self-center order-1">
                    <ul class="breadcrumb breadcrumb-light d-block text-center">
                        <li><a href="{{route('home')}}">{{__('nav.home')}}</a></li>
                        <li><a href="#"> {{__('nav.about-us')}}</a></li>
                        <li class="active">{{__('nav.about-us-1')}}</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <div>
        <h1 class="text-center">{{__('description.title')}}</h1>
    </div>



@endsection