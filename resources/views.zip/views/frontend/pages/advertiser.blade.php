@extends('frontend.layouts.app')
@section('description')
<meta name="description" content="" />
@endsection
@section('keywords')
<meta name="keywords" content="" />
@endsection
@section('title', 'Annonceur')
@section('content')

<section class="page-header page-header-modern page-header-background page-header-background-pattern page-header-background-sm overlay overlay-color-dark overlay-show overlay-op-5" style="background-image: url(img/patterns/wild_oliva.png);">
					<div class="container">
						<div class="row">
							<div class="col-md-12 align-self-center p-static order-2 text-center">
								<h1> Prise en main de votre <strong>Plateforme</strong></h1>
							</div>
							<div class="col-md-12 align-self-center order-1">
								<ul class="breadcrumb breadcrumb-light d-block text-center">
									<li><a href="{{route('home')}}">Accueil</a></li>
									<li><a href="#">A propos</a></li>
									<li class="active">Annonceurs</li>
								</ul>
							</div>
						</div>
					</div>
				</section>
		<section class="section bg-color-grey section-height-3 border-0 mt-5 mb-0">
					<div class="container">

						<div class="row">
							<div class="col">

								<div class="row align-items-center pt-4 appear-animation" data-appear-animation="fadeInLeftShorter">
									<div class="col-md-4 mb-4 mb-md-0">
										<img class="img-fluid scale-2 pr-5 pr-md-0 my-4" src="{{asset('img/pub.jpg')}}" alt="layout styles" />
									</div>
									<div class="col-md-8 pl-md-5">
										<h2 class="font-weight-normal text-6 mb-3"><strong class="font-weight-extra-bold">Espace</strong> Publicitaire</h2>
										<p class="text-4">Nous pouvons mettre en avant vos produits sur notre plateforme. Gagnez en vsibilité sur vos services.</p>
									</div>
								</div>

								<hr class="solid my-5">

								<div class="row align-items-center pt-5 pb-3 appear-animation" data-appear-animation="fadeInRightShorter">
									<div class="col-md-8 pr-md-5 mb-5 mb-md-0">
										<h2 class="font-weight-normal text-6 mb-3"><strong class="font-weight-extra-bold">Newsletters</strong> </h2>
										<p class="text-4">Nous envoyons tous les mois des newsletters à nos abonnés. Aitteignez les directement en reservant un espace publicitaire</p>
										<p>Contact: <a href="mailto:contact@beconbank.com">mailto:contact@beconbank.com</a></p>
									</div>
									<div class="col-md-4 px-5 px-md-3">
										<img class="img-fluid scale-2 my-4" src="{{asset('img/newsletter.jpg')}}" alt="style switcher" />
									</div>
								</div>
							</div>
						</div>
					</div>
				</section>	

@endsection