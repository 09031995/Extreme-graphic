@extends('frontend.layouts.app')
@section('description')
<meta name="description" content="" />
@endsection
@section('keywords')
<meta name="keywords" content="" />
@endsection
@section('title', 'Mobile Banking')
@section('content')
<section class="page-header page-header-modern page-header-background page-header-background-pattern page-header-background-sm overlay overlay-color-dark overlay-show overlay-op-5" style="background-image: url(img/patterns/wild_oliva.png);">
					<div class="container">
						<div class="row">
							<div class="col-md-12 align-self-center p-static order-2 text-center">
								<h1>{{__('contact.message-title')}}</h1>
							</div>
							<div class="col-md-12 align-self-center order-1">
								<ul class="breadcrumb breadcrumb-light d-block text-center">
									<li><a href="#">{{__('nav.home')}}</a></li>
									<li class="active">Contact</li>
								</ul>
							</div>
						</div>
					</div>
				</section>
<div class="container">
	<div class="row py-4">
						<div class="col-lg-6">

							<div class="overflow-hidden mb-1">
								<h2 class="font-weight-normal text-7 mt-2 mb-0 appear-animation" data-appear-animation="maskUp" data-appear-animation-delay="200">{{__('contact.contact')}}</h2>
							</div>
							<div class="overflow-hidden mb-4 pb-3">
								<p class="mb-0 appear-animation" data-appear-animation="maskUp" data-appear-animation-delay="400">{{__('contact.contact-desc')}}</p>
							</div>

							<form id="contactForm" class="contact-form" action="{{route('contact.send')}}" method="POST">
								@csrf
								@if(session('status'))
							      <div class="contact-form-success alert alert-success mt-4" id="contactSuccess">
							            {{ session('status') }}
							      </div>
							    @endif
							
								<div class="contact-form-error alert alert-danger d-none mt-4" id="contactError">
									<strong>Error!</strong> There was an error sending your message.
									<span class="mail-error-message text-1 d-block" id="mailErrorMessage"></span>
								</div>
								
								<div class="form-row">
									<div class="form-group col-lg-6">
										<label class="required font-weight-bold text-dark text-2">{{__('contact.name-form')}}</label>
										<input type="text" value="" data-msg-required="Please enter your name." maxlength="100" class="form-control" name="name" id="name" required>
									</div>
									<div class="form-group col-lg-6">
										<label class="required font-weight-bold text-dark text-2">{{__('contact.email-form')}}</label>
										<input type="email" value="" data-msg-required="Please enter your email address." data-msg-email="nter a valid email address." maxlength="100" class="form-control" name="email" id="email" required>
									</div>
								</div>
								<div class="form-row">
									<div class="form-group col-lg-6">
										<label class="required font-weight-bold text-dark text-2">{{__('contact.subjet-form')}}</label>
										<input type="text" value="" data-msg-required="Please enter the subject." maxlength="100" class="form-control" name="subject" id="subject" required>
									</div>
									<div class="form-group col-lg-6">
										<label class="font-weight-bold text-dark text-2">{{__('contact.phone-form')}}</label>
										<input type="text" value="" maxlength="20" class="form-control" name="phone" id="phone">
									</div>
								</div>
								<div class="form-row">
									<div class="form-group col">
										<label class="required font-weight-bold text-dark text-2">{{__('contact.message-form')}}</label>
										<textarea maxlength="5000" data-msg-required="Please enter your message." rows="8" class="form-control" name="message" id="message" required></textarea>
									</div>
								</div>
								<div class="form-row">
									<div class="form-group col">
										<input type="submit" value="{{__('contact.btn-envoie')}}" class="btn btn-primary btn-modern" data-loading-text="Loading...">
									</div>
								</div>
							</form>

						</div>
						<div class="col-lg-6">

							<div class="appear-animation" data-appear-animation="fadeIn" data-appear-animation-delay="800">
								<h4 class="mt-2 mb-1">{{__('contact.office')}}</h4>
								<ul class="list list-icons list-icons-style-2 mt-2">
									<li><i class="fas fa-map-marker-alt top-6"></i> {{__('contact.address')}}</li>
									<li><i class="fas fa-phone top-6"></i> {{__('contact.phone')}}</li>
									<li><i class="fas fa-envelope top-6"></i> <strong class="text-dark">{{__('contact.email')}}</strong> <a href="mailto:mail@example.com">{{__('contact.email-desc')}}</a></li>
								</ul>
							</div>

							<div class="appear-animation" data-appear-animation="fadeIn" data-appear-animation-delay="950">
								<h4 class="pt-5">{{__('contact.hours')}}</h4>
								<ul class="list list-icons list-dark mt-2">
									<li><i class="far fa-clock top-6"></i>{{__('contact.heure-1')}}</li>
									<li><i class="far fa-clock top-6"></i>{{__('contact.heure-2')}}</li>
									<li><i class="far fa-clock top-6"></i> {{__('contact.heure-3')}}</li>
								</ul>
							</div>

							<h4 class="pt-5">{{__('contact.get-touch')}}</h4>
							<p class="lead mb-0 text-4">{{__('contact.get-touch-desc')}}</p>

						</div>

					</div>
				</div>

@endsection