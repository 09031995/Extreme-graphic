@extends('frontend.layouts.app')
@section('description')
<meta name="description" content="" />
@endsection
@section('keywords')
<meta name="keywords" content="" />
@endsection
@section('title', 'Vous êtes EMF ou Banque')
@section('content')

<section class="page-header page-header-modern page-header-background page-header-background-pattern page-header-background-sm overlay overlay-color-dark overlay-show overlay-op-5" style="background-image: url(img/patterns/wild_oliva.png);">
					<div class="container">
						<div class="row">
							<div class="col-md-12 align-self-center p-static order-2 text-center">
								<h1>{{__('nav.emf-bank')}}</h1>
							</div>
							<div class="col-md-12 align-self-center order-1">
								<ul class="breadcrumb breadcrumb-light d-block text-center">
									<li><a href="{{route('home')}}">{{__('nav.home')}}</a></li>
									<li class="active">{{__('nav.emf-bank')}}</li>
								</ul>
							</div>
						</div>
					</div>
				</section>
		<div role="main" class="main">
			<div class="container">
				<div class="row">
						<div class="col-lg-6">
							<div class="overflow-hidden mb-1">
								<h2 class="font-weight-normal text-7 mt-2 mb-0 appear-animation" data-appear-animation="maskUp" data-appear-animation-delay="200">{{__('emf-bank.connected-relationship')}}</h2>
							</div>
							<div class="overflow-hidden">
								<p class="lead mb-0 appear-animation" data-appear-animation="maskUp" data-appear-animation-delay="200">
								{{__('emf-bank.get-new-customers')}}
								</p>
							</div>
						</div>
						<div class="col-lg-6 appear-animation" data-appear-animation="fadeIn" data-appear-animation-delay="500">
							<img src="{{asset('img/microfinance.jpg')}}" style="width: 100%; margin-bottom: 40px">
						</div>
					</div>
			</div>
			
				<div class="container-fluid">
				<div class="overflow-hidden mb-1 container">
					<h2 class="font-weight-normal text-7 mt-2 mb-0 appear-animation" data-appear-animation="maskUp" data-appear-animation-delay="200">{{__('emf-bank.services-available')}}</h2>
				</div>
					<div class="row featured-boxes-full featured-boxes-full-scale">
						<div class="col-lg-2 featured-box-full featured-box-full-primary">
							<i class="far fa-user"></i>
							<h4>{{__('emf-bank.service-1')}}</h4>
						</div>
						<div class="col-lg-2 featured-box-full featured-box-full-primary">
							<i class="fas fa-check-double"></i>
							<h4>{{__('emf-bank.service-2')}}</h4>
						</div>
						<div class="col-lg-2 featured-box-full featured-box-full-primary">
							<i class="far fas fa-file-upload"></i>
							<h4>{{__('emf-bank.service-3')}}</h4>
						</div>
						<div class="col-lg-2 featured-box-full featured-box-full-primary">
							<i class="far fa-plus-square"></i>
							<h4>{{__('emf-bank.service-4')}}</h4>
						</div>
						<div class="col-lg-2 featured-box-full featured-box-full-primary">
							<i class="far fa-file-alt"></i>
							<h4>{{__('emf-bank.service-5')}}</h4>
						</div>
						<div class="col-lg-2 featured-box-full featured-box-full-primary">
							<i class="fas fa-user-lock"></i>
							<h4>{{__('emf-bank.service-6')}}</h4>
						</div>
					</div>
				</div>
			<section class="section section-height-2 border-0 mt-5 mb-0 pt-5">
				<div class="container">
					<div class="row">
						<div class="overflow-hidden mb-1 container">
						<h2 class="font-weight-normal text-7 mt-2 mb-0 appear-animation" data-appear-animation="maskUp" data-appear-animation-delay="200">{{__('emf-bank.beconbank-advantages')}}</h2>
					</div>
						<div class="featured-boxes featured-boxes-style-2">
							<div class="row">
								<div class="col-md-6 col-lg-4 appear-animation" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="700">
									<div class="featured-box featured-box-effect-4">
										<div class="box-content">
											<i class="icon-featured icon-badge icons text-color-light bg-color-primary"></i>
											<h4 class="font-weight-bold">{{__('emf-bank.advantage-1')}}</h4>
											<p class="px-3">{{__('emf-bank.advantage-1-desc')}}</p>
										</div>
									</div>
								</div>
								<div class="col-md-6 col-lg-4 appear-animation" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="900">
									<div class="featured-box featured-box-effect-4">
										<div class="box-content">
											<i class="icon-featured icon-layers icons text-color-light bg-color-primary"></i>
											<h4 class="font-weight-bold">{{__('emf-bank.advantage-2')}}</h4>
											<p class="px-3">{{__('emf-bank.advantage-2-desc')}}</p>
										</div>
									</div>
								</div>
								<div class="col-md-6 col-lg-4 appear-animation" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="1100">
									<div class="featured-box featured-box-effect-4">
										<div class="box-content">
											<i class="icon-featured icon-people icons text-color-light bg-color-primary"></i>
											<h4 class="font-weight-bold">{{__('emf-bank.advantage-3')}}</h4>
											<p class="px-3">{{__('emf-bank.advantage-3-desc')}}</p>
										</div>
									</div>
								</div>
								<div class="col-md-6 col-lg-4 appear-animation" data-appear-animation="fadeInLeftShorter" data-appear-animation-delay="1500">
									<div class="featured-box featured-box-effect-4">
										<div class="box-content">
											<i class="icon-featured icon-star icons text-color-light bg-color-primary"></i>
											<h4 class="font-weight-bold">{{__('emf-bank.advantage-4')}}</h4>
											<p class="px-3">{{__('emf-bank.advantage-4-desc')}}</p>
										</div>
									</div>
								</div>
								<div class="col-md-6 col-lg-4 appear-animation" data-appear-animation="fadeInLeftShorter" data-appear-animation-delay="1300">
									<div class="featured-box featured-box-effect-4">
										<div class="box-content">
											<i class="icon-featured icon-screen-tablet icons text-color-light bg-color-primary"></i>
											<h4 class="font-weight-bold">{{__('emf-bank.advantage-5')}}</h4>
											<p class="px-3">{{__('emf-bank.advantage-5-desc')}}</p>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
				<div class="container">
					<div class="row">
						<div class="overflow-hidden mb-1 container">
							<h2 class="font-weight-normal text-7 mt-2 mb-0 appear-animation" data-appear-animation="maskUp" data-appear-animation-delay="200">{{__('emf-bank.become-partner')}}</h2>
						</div>
						<div class="col-lg-6">

								<div class="overflow-hidden mb-1">
									<button type="button" class="btn btn-3d btn-primary mb-2"> {{__('emf-bank.fill-form')}} </button>
								</div>
								<div class="overflow-hidden mb-4 pb-3">
									<p class="mb-0 appear-animation" data-appear-animation="maskUp" data-appear-animation-delay="400">{{__('emf-bank.fill-form-desc')}}</p>
								</div>

								<form id="contactForm" class="contact-form" action="{{route('contact.send')}}" method="POST">
									@csrf
									@if(session('status'))
								      <div class="contact-form-success alert alert-success mt-4" id="contactSuccess">
								            {{ session('status') }}
								      </div>
								    @endif
								
									<div class="contact-form-error alert alert-danger d-none mt-4" id="contactError">
										<strong>Error!</strong> There was an error sending your message.
										<span class="mail-error-message text-1 d-block" id="mailErrorMessage"></span>
									</div>
									
									<div class="form-row">
										<div class="form-group col-lg-6">
											<label class="required font-weight-bold text-dark text-2">{{__('emf-bank.company-name')}}</label>
											<input type="text" value="" data-msg-required="Please enter your name." maxlength="100" class="form-control" name="enteprise" id="enteprise" required>
										</div>
										<div class="form-group col-lg-6">
											<label class="required font-weight-bold text-dark text-2">{{__('emf-bank.activity-area')}}</label>
											<input type="text" value="" data-msg-required="Please enter your name." maxlength="100" class="form-control" name="activity" id="activity" required>
										</div>
										<div class="form-group col-lg-6">
											<label class="required font-weight-bold text-dark text-2">{{__('emf-bank.form-name')}}</label>
											<input type="text" value="" data-msg-required="Please enter your name." maxlength="100" class="form-control" name="name" id="name" required>
										</div>
										<div class="form-group col-lg-6">
											<label class="required font-weight-bold text-dark text-2">{{__('emf-bank.email')}} </label>
											<input type="email" value="" data-msg-required="Please enter your email address." data-msg-email="nter a valid email address." maxlength="100" class="form-control" name="email" id="email" required>
										</div>
										<div class="form-group col-lg-12">
											<label class="font-weight-bold text-dark text-2">{{__('emf-bank.form-phone')}} </label>
											<input type="text" value="" maxlength="20" class="form-control" name="phone" id="phone">
										</div>
									</div>
									<div class="form-row">
										<div class="form-group col">
											<label class="required font-weight-bold text-dark text-2">Message</label>
											<textarea maxlength="5000" data-msg-required="Please enter your message." rows="8" class="form-control" name="message" id="message" required></textarea>
										</div>
									</div>
									<div class="form-row">
										<div class="form-group col">
											<input type="submit" value="{{__('emf-bank.btn-submit')}}" class="btn btn-primary btn-modern" data-loading-text="Loading...">
										</div>
									</div>
								</form>

							</div>
							<div class="col-lg-1 hidden-xs"></div>
							<div class="col-lg-5">

								<div class="appear-animation" data-appear-animation="fadeIn" data-appear-animation-delay="800" style="min-height: 200px">
									<button type="button" class="btn btn-3d btn-primary mb-2"> {{__('emf-bank.become-partner-2')}}</button><br>&nbsp;<br> {{__('emf-bank.become-partner-2-desc')}}<br><br> 
								</div>

								<div class="appear-animation" data-appear-animation="fadeIn" data-appear-animation-delay="950" style="min-height: 200px">
									<button type="button" class="btn btn-3d btn-primary mb-2">  {{__('emf-bank.become-partner-3')}}</button>&nbsp;<br> {{__('emf-bank.become-partner-3-desc')}}<br><br> 
								</div>
								<div class="appear-animation" data-appear-animation="fadeIn" data-appear-animation-delay="1000" style="min-height: 200px">
									<button type="button" class="btn btn-3d btn-primary mb-2"> {{__('emf-bank.become-partner-4')}} </button>&nbsp;<br> {{__('emf-bank.become-partner-4-desc')}}<br><br> 
								</div>							

							</div>
					</div>
				</div>
				
		</div>	

@endsection