@extends('frontend.layouts.app')
@section('description')
<meta name="description" content="" />
@endsection
@section('keywords')
<meta name="keywords" content="" />
@endsection
@section('title', 'Mobile Banking')
@section('content')
<section class="page-header page-header-modern page-header-background page-header-background-pattern page-header-background-sm overlay overlay-color-dark overlay-show overlay-op-5" style="background-image: url(img/patterns/wild_oliva.png);">
					<div class="container">
						<div class="row">
							<div class="col-md-12 align-self-center p-static order-2 text-center">
								<h1>{{__('parteners.title-1')}} <strong>{{__('parteners.title-2')}}</strong></h1>
							</div>
							<div class="col-md-12 align-self-center order-1">
								<ul class="breadcrumb breadcrumb-light d-block text-center">
									<li><a href="#">{{__('nav.home')}}</a></li>
									<li class="active">{{__('nav.parteners')}}</li>
								</ul>
							</div>
						</div>
					</div>
				</section>
	<div class="container py-4">

					<ul class="nav nav-pills sort-source sort-source-style-3 justify-content-center" data-sort-id="team" data-option-key="filter">
						<li class="nav-item" data-option-value="*"><a class="nav-link text-1 text-uppercase" href="#"></a></li>
					</ul>

					<div class="sort-destination-loader sort-destination-loader-showing mt-4 pt-2">
						<div class="row team-list sort-destination" data-sort-id="team">
							<div class="col-12 col-sm-6 col-lg-3 isotope-item leadership">
								<span class="thumb-info thumb-info-hide-wrapper-bg mb-4">
									<span class="thumb-info-wrapper">
										<a href="{{route('partner.description')}}">
											<img src="{{ asset('img/logo3.jpg') }}" class="img-fluid" alt=""  style="height: 95px; margin-bottom: 82px;">
											<span class="thumb-info-title">
												<span class="thumb-info-inner">{{__('parteners.structure')}}</span>
												<span class="thumb-info-type">{{__('parteners.numero')}}</span>
											</span>
										</a>
									</span>
									<span class="thumb-info-caption">
										<span class="thumb-info-caption-text">{{__('parteners.text')}}</span>
										<span class="mb-4">
											<a href="{{route('partner.description')}}" class="btn btn-outline btn-rounded btn-primary  btn-with-arrow mb-2">Plus d'infos <span><i class="fas fa-chevron-right"></i></span></a>
										</span>
									</span>
								</span>
							</div>
						</div>

					</div>

				</div>
@endsection