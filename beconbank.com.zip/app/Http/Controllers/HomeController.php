<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Repositories\ContactRepository;


class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */

    /**
     * @var compagnyRepository
     */
    protected $contactRepository;

    public function __construct(ContactRepository $contactRepository)
    {
        $this->contactRepository = $contactRepository;
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('welcome');
    }

    public function partner()
    {
        return view('frontend.pages.partners');
    }

    public function partnerDescription(){

        return view('frontend.pages.partner-description');
    }

    public function faq()
    {
        return view('frontend.pages.faq');
    }

    public function web()
    {
        return view('frontend.pages.web');
    }

    public function mobile()
    {
        return view('frontend.pages.mobile');
    }

    public function emfBank(){
        return view('frontend.pages.emf-bank');
    }

    public function description(){
        return view('frontend.pages.description');
    }

    public function privacy(){
        return view('frontend.pages.privacy');
    }

    public function advertiser()
    {
        return view('frontend.pages.advertiser');
    }

    public function contact()
    {
        return view('frontend.pages.contact');
    }

    public function send(Request $request)
    {
        $contact = $this->contactRepository->store($request->input());
        //dd($contact);
        \Mail::send('frontend.mails.contact', compact('contact'), function($message) 
                {
                    $message->to(['jbiemewou@gmail.com'])->subject('Nouveau contact')->from('contact@beconbank.com', 'Becon\'Bank');
                });
        return redirect()->back()->with('status', 'Merci de nous avoir contacté. Nous vous reviendrons dans dès que possible');
    }
}
