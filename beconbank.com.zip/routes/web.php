<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

$segment = Request::segment('1');


Route::get('/{lang?}', function () {
    return view('welcome');
})->where('lang', implode('|', array_flip(config('app.languages'))));

Auth::routes();

Route::group(['prefix' => $segment], function () {
	Route::get('/home', 'HomeController@index')->name('home');
	Route::get('/partner', 'HomeController@partner')->name('partner');
	Route::get('/partner/description', 'HomeController@partnerDescription')->name('partner.description');
	Route::get('/faq', 'HomeController@faq')->name('faq');
	Route::get('/contact', 'HomeController@contact')->name('contact');
	Route::post('/contact/send', 'HomeController@send')->name('contact.send');
	Route::get('/about-us/advertiser', 'HomeController@advertiser')->name('about-us.advertiser');
	Route::get('/about-us/web', 'HomeController@web')->name('about-us.web');
    Route::get('/about-us/mobile', 'HomeController@mobile')->name('about-us.mobile');
	Route::get('/emf-bank', 'HomeController@emfBank')->name('emf-bank');
    Route::get('/description', 'HomeController@description')->name('description');
    Route::get('/privacy', 'HomeController@privacy')->name('privacy');
});
