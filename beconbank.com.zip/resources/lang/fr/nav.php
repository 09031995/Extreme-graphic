<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Pagination Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the paginator library to build
    | the simple pagination links. You are free to change them to anything
    | you want to customize your views to better match your application.
    |
    */

    'home' => 'Accueil',
    'title' => 'Prise en main de votre',
    'title-2' => 'plateforme',
    'about-us' => 'Fonctionnalité',
    'about-us-1' => 'Aide utilisateurs',
    'about-us-2' => 'Qui sommes nous',
    'about-us-3' => 'Fonctionnalité web',
    'about-us-4' => 'Fonctionnalité application mobile ',
    'parteners' => 'Partenaires',
    'contact' => "Contacts",
    'emf-bank' => "Vous êtes EMF / Banque",
    'sign-in' => "Se connecter",
    'sign-out' => "Créer un compte",
    'copyrights' => 'Tous droits réservés',
    'general-condition' => 'Conditions Générales',
    'legal-notice' => 'Mentions Légales',
    'privacy-policy' => 'Politique de confidentialité',
    'faq' => 'Foire aux questions',
    'label' => 'Inscrivez vous à notre Newletter et restez connecté:',
];
