<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Pagination Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the paginator library to build
    | the simple pagination links. You are free to change them to anything
    | you want to customize your views to better match your application.
    |
    */

    "connected-relationship" => "Relation connectée avec ses clients",
    "get-new-customers" => "Obtenez rapidement de nouveaux clients,fidélisez vos clients actuels",
    "services-available" => "Pourquoi Becon’bank ?",
    "service-1" => "Gestion de la clientèle    ",
    "service-2" => "Validation des transactions",
    "service-3" => "Importation des données du SI à Becon'Bank",
    "service-4" => "Services additionnels",
    "service-5" => "Rapport analytique",
    "service-6" => "Administration",
    "beconbank-advantages" => "Avantages Becon'bank ",
    "advantage-1" => "Satisfaction client",
    "advantage-1-desc" => "Améliorer la satisfaction client en leur fournissant des services à valeur ajoutée et à coût abordable",
    "advantage-2" => "Efficacité opérationnelle",
    "advantage-2-desc" => "Améliorer l'efficacité opérationnelle de l'EMF/Banques : grâce à de nouvelles fonctionnalité en temps réel (reporting, etc.)",
    "advantage-3" => "Employés de la microfinance",
    "advantage-3-desc" => "Concentrer les employés de l'EMF/Banques sur des activités à valeur ajoutée : en réduisant les sollicitations des clients dans les agences.",
    "advantage-4" => "Fluidité des actions",
    "advantage-4-desc" => "Rendre les actions de vos clients plus fluides : pour assurer leur fidélité.",
    "advantage-5" => "Etablissement digital",
    "advantage-5-desc" => "devenir un établissement financier digital : en réduisant les risques de pertes et vols d'argent",
    "become-partner" => "Devenir EMF Partenaire",
    "fill-form" => "(1) Remplissez le formulaire",
    "fill-form-desc" => "Nous prenons contact avec vous pour finaliser la création de votre compte partenaire",
    "company-name" => "Nom de l'entreprise",
    "activity-area" => "Secteur d'activités",
    "form-name" => "Nom du contact",
    "form-phone" => "Téléphone",
    "email" => "Email",
    "btn-submit" => "Envoyer",
    "become-partner-2" => "(2) Stratégie de lancement de la solution",
    "become-partner-2-desc" => "Recevez votre kit de lancement. Nous nous assurerons que vous avez tous les supports pour le lancement de la solution",
    "become-partner-3" => "(3) Faites adhérer vos clients à la solution Becon'Bank",
    "become-partner-3-desc" => "Les clients existants ou nouveaux pourront effectuer les transactions depuis la plateforme Becon'bank",
    "become-partner-4" => "(4) Suivez vos opérations et ceux de vos clients",
    "become-partner-4-desc" => "Ayez une visibilité en temps réel de votre compte EMF / Banques. Ayez un reporting de toutes les transactions de vos clients.",
];
