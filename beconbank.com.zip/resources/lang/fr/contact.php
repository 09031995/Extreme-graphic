<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Pagination Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the paginator library to build
    | the simple pagination links. You are free to change them to anything
    | you want to customize your views to better match your application.
    |
    */

    "message-title" => "Laissez-nous un Message",
    "contact" => "Contactez nous",
    "contact-desc" => "N'hésitez pas à demander des détails, ne garder aucune question pour vous!",
    "name-form" => "Nom complet",
    "email-form" => "Adresse email",
    "subjet-form" => "Sujet",
    "phone-form" => "Téléphone",
    "message-form" => "Message",
    "btn-envoie" => "Envoyer",
    "office" => "Notre bureau",
    "address" => "Addresse: Akwa, Rue Ancien Sonel",
    "phone" => "Tel: 652812315",
    "email" => "Email:",
    "email-desc" => "contact@beconbank.com",
    "hours" => "Heures de travail",
    "heure-1" => "Du lundi au vendredi de 9h à 18h",
    "heure-2" => "Samedi - 9h à 14h",
    "heure-3" => "Dimanche - fermé",
    "get-touch" => "Entrer en contact",
    "get-touch-desc" => "",
];