<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Pagination Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the paginator library to build
    | the simple pagination links. You are free to change them to anything
    | you want to customize your views to better match your application.
    |
    */

    'title' => 'MICROFINANCE ACADEMY',
    'texte' => 'Microfinance Academy est une organisation experte dans l’assistance du secteur de la microfinance et de la micro-entreprise en Afrique à travers les études, la formation, l’assistance technique, les conseils, etc. Microfinance Academy est un partenaire agréé auprès du Consultative Group to Assist the Poor (CGAP- Banque mondiale). Ce dernier soutient l’institution à travers un programme de renforcement des capacités de ses formateurs depuis près d’une quinzaine d’années.',
    'title-2' => 'L’organisation travaille essentiellement avec :',
    'liste-1' => 'Les établissements de microfinance et leurs réseaux',
    'liste-2' => 'Les instances de réglementation',
    'liste-3' => 'Les bailleurs de fonds',
    'liste-4' => 'Les cabinets conseils',
    'liste-5' => 'Les banques commerciales classiques',
    'liste-6' => 'Les ministères en charge de la microfinance et de la micro-entreprise.',
    'title-3' => 'Microfinance Academy a pour objectif de :',
    'liste-7' => 'Accroître les aptitudes des acteurs de la microfinance et de la micro-entreprise en Afrique.',
    'liste-8' => 'Appuyer les établissements de microfinance sur la voie de l’innovation et de la recherche-action. ',
    'liste-9' => 'Apporter aux établissements de microfinance et aux micro-entreprises des informations sur les bailleurs de fonds qui soutiennent le secteur de la microfinance et de la micro-entreprise dans le monde.',
    'liste-10' => 'Réunir et diffuser l’information sur les pratiques en matière de gestion auprès des établissements de microfinance et de la micro-entreprise ',


];