<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Pagination Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the paginator library to build
    | the simple pagination links. You are free to change them to anything
    | you want to customize your views to better match your application.
    |
    */

    'slide-1' => 'Restez connecté à votre banque',
    'text-1' => 'Restez connecté',
    'text-2' => 'à votre banque',
    'next' => 'Next &raquo;',
    "main-features" => "Pourquoi Becon’bank ?",
    "feature-1" => "Consulter en temps réel le solde de votre compte",
    "feature-1-desc" => "En quelques clics, vous pouvez consulter votre solde bancaire via un ordinateur, une tablette ou un smartphone",
    "feature-2" => "Consulter l'historique des transactions ",
    "feature-2-desc" => "Avec Becon'Bank vous pouvez consulter l’historique de toutes vos transactions",
    "feature-3" => "Effectuer les dépôts et les retraits via les comptes mobiles money",
    "feature-3-desc" => "Becon'Bank relie la microfinance et la banque à leurs clients, leur permettant de réaliser les transactions financières à distance depuis leur téléphone portable",
    "feature-4" => "Retrouver les différentes agences de votre établissement de microfinance / banque",
    "feature-4-desc" => "Becon’bank répertorie la liste des agences des établissements de microfinances/Banques pour vous simplifier la vie",
    "feature-5" => "Effectuer les transactions à l'un de vos proches sur son compte mobile money, sur son compte bancaire ou à travers un retrait en agence",
    "feature-5-desc" => "Effectuer des transferts d’argent instantanément vers des comptes de tiers ou des retraits en agence",
    "feature-6" => "Gérer tous vos comptes dans une même application :",
    "feature-6-desc" => "Becon’bank vous donne la possibilité d'effectuer des opérations bancaires avec tous vos comptes dans une même application",
    "beconbank-advantages" => "Avantages Becon'Bank",
    "advantage-1" => "Réduction des files d'attente dans les agences",
    "advantage-2" => "Diminution des risques de pertes et vols d'argent",
    "advantage-3" => "Accès 24/7 à la plateforme",
    "advantage-4" => "Notification par SMS/Email",
    "advantage-5" => "Accès à un ensemble de services: retrait, dépôt, transfert d'argent ",
    "advantage-6" => "Visibilité de votre solde en temps réel",
    "how-it-works" => "Comment ça marche?",
    "how-it-works-1" => "Rapprochez vous de votre conseiller clientèle, qui vous assistera pour l'activation du service et le téléchargement de l'application",
    "how-it-works-2" => "Connectez vous sur la plateforme Becon'Bank. Effectuez vos transactions: dépôt, retrait, transfert d'argent",
    "how-it-works-3" => "Découvrez tout notre réseau de partenaires",

];
