<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Pagination Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the paginator library to build
    | the simple pagination links. You are free to change them to anything
    | you want to customize your views to better match your application.
    |
    */

    'entete-1' => 'Confidentialité',
    'entete-2' => 'Politique de confidentialité',
    'title' => 'Politique de confidentialité pour Becon’Bank',
    'article-1' => 'Article 1 – Information importante ',
    'article-1-desc' => ' La Société INIMOV SAS reconnaît l’importance de la confidentialité et de la sécurité des informations personnelles de nos clients. Nous apprécions la confiance que vous nous accordez pour protéger vos informations personnelles et respecter votre droit à la vie privée. Alors que les nouvelles technologies ont radicalement changé la manière dont les informations sont collectées, utilisées et stockées, préserver la confiance des clients et la confidentialité des informations personnelles chez INIMOV SAS reste un objectif fondamental. Nous pensons qu\'il est important d\'indiquer clairement à nos clients comment Becon’Bank collecte, utilise et partage les informations, les avantages d\'une telle utilisation et les protections mises en place contre les accès et utilisations non autorisés. Nous respectons votre vie privée et la confidentialité de vos informations personnelles, et nous apprécions la possibilité de faire affaire avec vous. ',
    'article-1-desc-2' => 'Nous collecterons, transférerons, traiterons et stockerons vos informations personnelles uniquement avec votre autorisation expresse, à moins que la loi ne l\'y oblige, et n\'utiliserons ces informations que dans le but licite pour lequel elles sont requises. Nous divulguerons le but spécifique pour lequel nous utilisons, demandons et stockons vos informations personnelles. Nous conserverons également un enregistrement de ces informations personnelles et du but spécifique pour lequel nous les recueillons. Nous n\'utiliserons pas vos informations personnelles à des fins autres que celles que nous vous avons divulguées, à moins que vous ne nous donniez votre consentement explicite à cet effet ou que nous soyons autorisés à le faire par la loi.',
    'article-2' => 'Article 2 – Données collectées sur Becon’Bank (application mobile et site web)',
    'article-2-desc' => ' Nous pouvons collecter des informations vous concernant lorsque vous vous enregistrez sur notre application mobile ou Site web. Nous ne recueillons aucune catégorie particulière de données personnelles vous concernant (cela inclut des détails sur votre race ou votre ethnie, vos croyances religieuses ou philosophiques, votre vie sexuelle, votre orientation sexuelle, vos opinions politiques, votre appartenance à un syndicat, des informations sur votre santé, ainsi que vos données génétiques et biométriques). Nous ne recueillons pas non plus d\'informations sur les condamnations pénales et les infractions.',
    'desc-2' => 'Nous allons collecter, stocker et utiliser les catégories d\'informations personnelles suivantes vous concernant comme suit :',
    'donnée-1' => 'Données d\'identité, ',
    'donnée-1-desc' => 'y compris les coordonnées personnelles telles que le nom et le titre.',
    'donnée-2' => 'Données financières, ',
    'donnée-2-desc' => 'y compris les détails de compte bancaire et autres informations bancaires.',
    'donnée-3' => 'Données de transactions, ',
    'donnée-3-desc' => 'y compris votre historique de facturation, les produits et services que vous utilisez et tout ce qui concerne votre compte.',
    'donnée-4' => 'Données de profil, ',
    'donnée-4-desc' => 'comprenant les informations que vous nous avez fournies dans vos communications avec nous, les informations que vous nous avez fournies lors de votre participation à des enquêtes.',
    'donnée-5' => 'Données de marketing et de communication, ',
    'donnée-5-desc' => 'y compris vos préférences en matière de réception de marketing de notre part et de la part de tiers, et vos préférences de communication.',
    'desc-3' => 'Il est important que les données personnelles que nous détenons sur vous soient exactes et à jour. Veuillez nous tenir au courant si vos données personnelles changent au cours de votre relation avec nous.',
    'article-3' => 'Article 3 – Méthode de Collecte des Données ',
    'article-3-desc' => ' Nous recueillons des informations personnelles à votre sujet lorsque vous souscrivez au service Becon’Bank, via un formulaire que vous remplissez, vous nous communiquer vos données d\'identité, de contact, financières et de transaction.',
    'article-4' => 'Article 4 – Utilisation des données collectées ',
    'article-4-desc' => ' Nous n\'utiliserons vos informations personnelles que lorsque la loi nous le permettra. Le plus souvent, nous utiliserons vos informations personnelles dans les cas ci-dessous :',
    'cas-1' => 'Nous utilisons les données que nous avons collectées pour vous authentifier et autoriser l\'accès à nos services sur le Site web et l\'application mobile.',
    'cas-2' => 'Nous vous contacterons par courrier électronique, et SMS, appel téléphonique et autres moyens via nos services, notamment des messages texte et des notifications. Nous vous vous enverrons des messages sur la disponibilité de nos services, la sécurité ou d’autres problèmes liés aux services.',
    'cas-3' => 'Nous vous servons des publicités personnalisées sur et en dehors de nos services. Nous ciblons les annonces de nos clients sur et hors services par le biais de divers réseaux et échanges d’annonces, en utilisant les données issues des technologies publicitaires de notre service et en dehors de celle-ci, ainsi que les informations provenant de partenaires publicitaires.',
    'cas-4' => 'Nous utilisons les données nécessaires pour enquêter, répondre et résoudre les plaintes et les problèmes de service.',
    'cas-5' => 'Nous utilisons vos données (y compris vos communications) si nous le jugeons nécessaire à des fins de sécurité ou pour enquêter sur des fraudes possibles ou d’autres violations de notre Contrat utilisateur ou de la présente Politique de confidentialité et / ou tenter de nuire à nos Membres ou à nos visiteurs.',
    'article-5' => 'Article 5 – Sécurité des données',
    'article-5-desc' => 'La protection de notre solution et les informations de nos utilisateurs est primordiale pour garantir aux clients de la marque, du Site Web et de notre application mobile une expérience sécurisée et le maintien de la confiance de nos utilisateurs. Nous avons pris les mesures suivantes pour protéger vos informations.',
    'mesure-1' => 'L’Editeur a mis en place des protections techniques, administratives et physiques pour aider à protéger contre tout accès, utilisation ou divulgation non autorisé des informations client que nous recueillons ou stockons. ',
    'mesure-2' => 'Nous mettons en œuvre diverses mesures de sécurité pour maintenir la sécurité de vos informations personnelles lorsque vous entrez, envoyez ou accédez à vos informations personnelles.',
    'mesure-3' => 'Vos informations personnelles peuvent être accessibles aux personnes autorisées avec des droits d\'accès spéciaux à de tels systèmes, et sont tenues de garder la confidentialité des informations. Les informations telles que les codes PIN et les mots de passe ne sont pas accessibles à notre personnel autorisé.',
    'mesure-4' => 'L’Editeur vous informe que vos données pourront être divulguées en application d’une loi, d’un règlement ou en vertu d’une décision d’une autorité réglementaire ou judiciaire compétente ou encore, si cela s’avère nécessaire, aux fins, pour l’Editeur, de préserver ses droits et intérêts.',
    'article-6' => 'Article 6 – Partage de vos données collectées',
    'article-6-desc' => 'Lorsque vous utilisez ou interagissez avec nos services, vous consentez au traitement, au partage, au transfert et à l\'utilisation de vos informations conformément à la présente politique de confidentialité. L’Editeur s\'efforce de se conformer à toutes les réglementations applicables en matière de protection des données et de la vie privée, y compris les réglementations générales de l\'UE relatives à la protection des données (RGP).',
    'article-6-desc-1' => 'Pour vous fournir nos services, vos informations personnelles peuvent être transférées vers d’autres partenaires afin de traiter et de stocker les données conformément à notre politique de confidentialité et de vous fournir des produits et services. Nous pouvons transférer vos données à des sociétés affiliées ou à des partenaires, y compris pour le traitement de données externalisé effectué pour le compte de l’Editeur.',
    'article-6-desc-2' => 'Dans tous les accords de partage, L’Editeur oblige ses prestataires de services et ses partenaires commerciaux à conserver ces informations conformément à une réglementation stricte en matière de protection de la vie privée et leur interdit de les divulguer à qui que ce soit à d\'autres fins.',
    'article-7' => 'Article 7 – Droits des Utilisateurs',
    'point-1' => 'Conservation des données',
    'point-1-desc' => 'Nous conservons la plupart de vos données personnelles aussi longtemps que votre compte est actif. Nous conservons les données personnelles que vous avez fournies pendant la durée de votre compte ou au besoin pour vous fournir nos services.',
    'point-2' => 'Droits d\'accès et de contrôle de vos données personnelles',
    'point-2-desc' => 'Vous pouvez accéder à vos données personnelles à partir de nos services lorsque vous suivez nos procédures concernant les demandes des personnes concernées. Vous pouvez toujours modifier ou mettre à jour vos données personnelles à l\'aide des menus appropriés du Site web ou de l\'application mobile.',
    'article-7-desc' => 'Lorsque vous souhaitez vous désactiver de ce service, vous devez envoyer une demande à votre Etablissement de microfinances, et elle en retour nous contactera pour valider la demande de traitement. Un compte désactivé peut toujours conserver un historique des transactions sur nos systèmes conformément aux lois financières et aux politiques de conservation des données de la Banque.',

];
