<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Pagination Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the paginator library to build
    | the simple pagination links. You are free to change them to anything
    | you want to customize your views to better match your application.
    |
    */

    'cash-deposit' => 'Dépôt d\'argent',
    'cash-deposit-1' => 'Dépot d\'argent avec MTN',
    'cash-deposit-2' => 'Dépot d\'argent avec avec Orange',
    'cash-transfer-1' => 'Transfert vers un compte bancaire',
    'cash-transfer-2' => 'Retrait en agence',
    'cash-withdrawal' => 'Retrait d\'argent',
    'cash-withdrawal-1' => 'Retrait vers mon numéro',
    'cash-withdrawal-2' => 'Retrait vers un autre numéro',
    'customer-setup' => "Profil client",
    'customer-title-1' => 'Se connecter à l’application mobile',
    'customer-title-2' => 'Visualiser le Profil',
    'customer-title-3' => 'Modifier mes informations',
    'customer-title-4' => 'Changer le mot de passe',
    'customer-title-5' => 'Changer le code secret',
    'customer-title-6' => 'Sortir de l’application',
    'customer-title-7' => 'Se déconnecter',
    'transaction-management' => "Gestion des transactions",
    'deposit-operator-1' => 'Avec MTN',
    'deposit-operator-1-desc-1' => "<p>Dans Becon’bank, le dépôt d’argent permet de mettre de l’argent dans votre compte bancaire à travers votre compte mobile money pour effectuer un dépôt, veuillez suivre les étapes suivantes :</p>
                        <p>1- cliquer sur « Opérations », après sélectionner « Dépôt d’argent »</p>
                        <p>Ou vous pouvez cliquer sur :</p>
                        <p>2- « dépôt d’argent »</p>",
    'deposit-operator-1-desc-2' => '<p>3- Remplir les champs, ensuite cliquer sur « Valider »</p>
                        <p>4- Vous recevrez un message de votre opérateur mobile pour confirmer l’opération</p>',
    'deposit-operator-1-desc-3' => '<p>5- Vous recevrez un message de votre Opérateur téléphonique dans votre téléphone</p>
                        <p>6- et un mail de Becon’Bank</p>
                        <p>7- La transaction passe au statut « confirmed »</p>',
    'deposit-operator-2' => 'Avec Orange',
    'deposit-operator-2-desc-1' => '<p>Dans Becon’bank, le dépôt d’argent permet de mettre de l’argent dans votre compte bancaire à travers votre compte mobile money pour effectuer un dépôt, veuillez suivre les étapes suivantes :</p>
                                    <p>1- cliquer sur « Opérations », après sélectionner « Dépôt d’argent »</p>
                                    <p>Ou vous pouvez cliquer sur :</p>
                                    <p>2- « dépôt d’argent »</p>',
    'deposit-operator-2-desc-2' => '<p>3- Remplir les champs, ensuite cliquer sur « Valider »</p>
                                    <p>Taper #150*4*4# sur votre téléphone pour générer le code marchand</p>
                                    <p>4- Code marchand (code de paiement)</p>
                                    <p>Le code de paiement est un code de sécurité mis par Orange Cameroun qui permet de sécuriser les retraits d’argent</p>',
    'deposit-operator-2-desc-3' => '5- Remplir les champs et cliquer sur « confirm »',
    'withdrawal-1-desc-1' => '<p>Retrait d’argent vers mon numéro de téléphone vous permet de retirer de l’argent de votre compte bancaire pour votre compte mobile money</p>
                                <p>Pour effectuer un  Retrait d’argent vers mon numéro de téléphone vous avez 02 possibilités</p>
                                <p><u>1ère possibilité :</u></p>
                                <p>1- cliquer sur « Opérations »</p>
                                <p>2- après sélectionner « Retrait d’argent »</p>
                                <p><u>2ème possibilité :</u></p>
                                <p>Ou vous pouvez cliquer sur:</p>
                                <p>1- « Retrait d’argent »</p>
                                <p>2- Ensuite sur « Retrait vers mon numéro de téléphone »</p>',
    'withdrawal-1-desc-2' => '<p>5- Remplir les champs</p>
                                <p>Client: votre nom complet</p>
                                <p>Choix du compte: vous devez choisir l’un de vos compte avec lequel vous souhaitez effectuer la transaction</p>
                                <p>Choix de l’opérateur: vous devez choisir entre  l’opérateur Orange et MTN</p>
                                <p>Téléphone: votre numéro de téléphone s’affiche automatiquement en fonction du choix de l’opérateur et ne peut pas être modifier</p>
                                <p>Montant à retirer code secret</p>
                                <p>6- cliquer sur « valider »</p>
                                <p>7- L’opération passe au statut « Unconfirmed » en attendant la validation de l’EMF/Banque</p>',
    'withdrawal-2-desc-1' => '<p>Retrait d’argent vers un autre numéro de téléphone vous de retirer de l’argent de votre compte bancaire vers le compte mobile money d’un de vos proches.</p>
                                <p>Pour effectuer un  Retrait d’argent vers un autre numéro de téléphone vous avez 02 possibilités</p>
                                <p><u>1ère possibilité :</u></p>
                                <p>1- cliquer sur « Opérations »,</p>
                                <p>2- après sélectionner « Retrait vers un autre numéro »</p>
                                <p>2ème possibilité :</p>
                                <p>Ou vous pouvez cliquer sur</p>
                                <p>3- « Retrait d’argent »</p>
                                <p>4- Ensuite sur « Retrait vers un autre numéro de téléphone »</p>',
    'withdrawal-2-desc-2' => '<p>5- Remplir les champs</p>
                                <p>Client: votre nom complet</p>
                                <p>Choix du compte: vous devez choisir l’un de vos compte avec lequel vous souhaitez effectuer la transaction</p>
                                <p>Choix de l’opérateur: vous devez choisir entre  l’opérateur Orange et MTN</p>
                                <p>Téléphone: numéro de téléphone vers lequel vous souhaitez envoyer de l’argent</p>
                                <P>Nom Récipiendaire: nom de votre bénéficiaire</P>
                                <p>Montant à retirer: montant que vous souhaitez retirer</p>
                                <p><strong>Code secret</strong></p>
                                <p>6- cliquer sur « valider »</p>
                                <p>7- L’opération passe au statut « Unconfirmed » en attendant la validation de l’EMF/Banque</p>',
    'transfer-desc-1' => '<p>Il existe deux types de transfert sur Becon’Bank :</p>
                                <ul>
                                    <li>Transfert vers un autre compte</li>
                                    <li>Transfert pour retrait en agence</li>
                                </ul>',
    'transfer-desc-2' => '<p>La fonctionnalité « transfert vers un compte » permet d’effectuer un transfert d’argent de votre compte bancaire vers un autre compte bancaire.</p>
                                <p><strong><u>NB:</u> Les comptes bancaires doivent être domiciliés dans le même établissement financier</strong></p>
                                <p>Pour transférer de l’argent vers un autre compte, vous avez 02 possibilité :</p>
                                <p>1ère possibilité :</p>
                                <p>1- cliquer sur « Opérations »,</p>
                                <p>2- après sélectionner « Transfert vers un compte  »</p>
                                <p>2ème possibilité :</p>
                                <p>3- cliquer sur « Transferts »,</p>
                                <p>4- Ensuite cliquer sur « Transfert vers un compte  »</p>',
    'transfer-desc-3' => '<p>5- remplir les champs</p>
                                <p>Numéro de compte: vous devez choisir l’un de vos compte avec lequel vous souhaitez effectuer la transaction</p>
                                <p>Compte receveur: numéro de compte bancaire dans lequel vous voulez transférer de l’argent</p>
                                <p>Nom récipiendaire: le nom complet du propriétaire du compte bénéficiaire</p>
                                <p>Montant à transférer Code secret: votre code secret</p>
                                <p>6- cliquer sur « valider le transfert »</p>
                                <p>7- l’opération passe au statut « unconfirmed » pour validation par l’EMF.</p>',
    'transfer-desc-4' => '<p>La fonctionnalité « Retrait en agence » permet d’envoyer de l’argent à une personne qui n’a pas soit un compte bancaire soit un compte domicilié dans votre établissement financier</p>
                                <p>Pour effectuer un transfert pour retrait en agence, vous avez 02 possibilités :</p>
                                <p><u>1ère possibilité :</u></p>
                                <p>1- cliquer sur « Opérations »,</p>
                                <p>2- après sélectionner « Retrait en agence »</p>
                                <p>2ème possibilité :</p>
                                <p>3- cliquer sur « Transferts »,</p>
                                <p>4- Ensuite cliquer sur « Pour retrait en agence »</p>',
    'transaction-desc-1' => '<p>La fonctionnalité Gestion transactions est subdivisée en 2 éléments</p>
                                <ul>
                                    <li>Transactions en cours : affiche l’ensemble des transactions en attente de validation par l’Administration</li>
                                    <li>Historique : affiche l’ensemble de vos transactions (confirmées, validées, payées)</li>
                                </ul>',
    'transaction-desc-2' => '<p>La fonctionnalité « transactions en cours » permet de visualiser les opérations qui doivent être confirmées par l’Administrateur.</p>
                                <p>Pour accéder à cette fonctionnalité, veuillez suivre les étapes suivantes :</p>
                                <p>1- cliquer sur « Gestion des Transaction».</p>
                                <p>2- cliquer sur « transactions en cours ».</p>
                                <p>3- Vous avez accès aux transactions en attente</p>',
    'transaction-desc-3' => '<p>La fonctionnalité « historique » permet de visualiser l’ensemble de toutes les transactions du client (dépôt, retrait, transfert, validées, confirmées, payées).</p>
                                <p>Pour accéder à cette fonctionnalité, veuillez suivre les étapes suivantes :</p>
                                <p>1- cliquer sur « Gestion des Transaction».</p>
                                <p>2- cliquer sur « Historique ».</p>
                                <p>3- Vous avez accès à l’historique</p>',
    'transaction-desc-4' => '<p>Vous avez la possibilité de visualiser vos transactions en fonction de vos différents comptes</p>
                                <p>1- aller dans « tableau de bord »</p>
                                <p>2- sélectionner un compte</p>',
    'transaction-desc-5' => '3- vous avez le solde et les transactions récentes du compte sélectionné',
    'profil-desc-1' => '<p>Après création du client par l’EMF/Banque, le client reçoit un email de confirmation</p>
                                <p>1- Copier votre mot de passe par défaut et retenez votre code secret par défaut</p>
                                <p>2- cliquez sur « cliquer ici pour vérifier votre compte »</p>
                                <p>Vous êtes redirigez vers la page de connexion</p>',
    'profil-desc-2' => 'p>Page de connexion</p>
                                <p>Veuillez entrer votre email ou votre numéro de téléphone et votre mot de passe</p>
                                <p>3- Cliquez sur « se connecter »</p>',
    'profil-desc-3' => '<ul>
                            <li>Tableau de bord: affiche le solde et les transactions récentes</li>
                            <li>Opérations: permet de faire les transactions (dépôt, retrait, transfert)</li>
                            <li>Gestion des transactions: permet de visualiser l’ensemble des transactions effectuées dans son compte</li>
                            <li>Dépôt d’argent: permet d’effectuer un dépôt du compte mobile money vers le compte bancaire</li>
                            <li>Retrait d’argent: permet d’effectuer les retraits d’argent du compte bancaire vers le compte mobile money</li>
                            <li>Transfert: permet d’effectuer les transferts vers un autre compte bancaire et les retraits en agence.</li>
                        </ul>',
    'profil-desc-4' => '<p>Pour changer de langue, veuillez suivre les étapes suivantes :</p>
                            <p>1- cliquer sur le symbole</p>
                            <p>2- sélectionner la langue de votre choix</p>',
    'profil-desc-5' => '<p>Pour « visualiser le Profil », veuillez suivre les étapes suivantes :</p>
                            <p>1- Cliquer sur votre nom</p>
                            <p>2- Cliquer sur « profil »</p>
                            <p>Vous avez accès à votre « profil »</p>',
    'profil-desc-6' => '<p>Pour changer le mot de passe de votre compte, veuillez suivre les étapes suivantes :</p>
                            <p>1- Cliquer sur votre nom</p>
                            <p>2- Cliquer sur « Changer Mot De Passe »</p>
                            <p>3- renseigner les champs et cliquer sur « Soumettre »</p>',
    'profil-desc-7' => '<div class="" style=" ">
                            <p>Le code secret permet de sécuriser les transactions.</p>
                            <p>Pour changer le code secret de votre compte, veuillez suivre les étapes suivantes :</p>
                            <p>1- Cliquer sur votre nom</p>
                            <p>2- Cliquer sur « Changer Code Secret »</p>
                            <p>3- renseigner les champs et cliquer sur « Soumettre »</p>',
    'profil-desc-8' => '<p>Pour « se déconnecter », veuillez suivre les étapes suivantes :</p>
                            <p>1- Cliquer sur votre nom</p>
                            <p>2- Cliquer sur « Déconnexion »</p>
                            <p>3- vous êtes redirigés vers la page d’accueil</p>',
];
