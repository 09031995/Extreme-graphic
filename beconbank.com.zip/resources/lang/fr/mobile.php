<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Pagination Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the paginator library to build
    | the simple pagination links. You are free to change them to anything
    | you want to customize your views to better match your application.
    |
    */

    'cash-deposit' => 'Dépôt d\'argent',
    'cash-deposit-1' => 'Dépot d\'argent avec MTN',
    'cash-deposit-2' => 'Dépot d\'argent avec avec Orange',
    'cash-transfer-1' => 'Transfert vers un compte bancaire',
    'cash-transfer-2' => 'Retrait en agence',
    'cash-withdrawal' => 'Retrait d\'argent',
    'cash-withdrawal-1' => 'Retrait vers mon numéro',
    'cash-withdrawal-2' => 'Retrait vers un autre numéro',
    'customer-setup' => "Profil client",
    'transaction-management' => "Gestion des transactions",
    'deposit-operator-1' => 'Avec MTN',
    'deposit-operator-1-desc-1' => "<p>Pour effectuer un dépôt, veuillez suivre les étapes suivantes :</p>
                                    <p>1- cliquer sur « Faire un dépôt »,</p>
                                    <p>Vous êtes redirigés vers la page de dépôt</p>
                                    <p>2- Remplir les champs</p>
                                    <ul>
                                        <li>Montant à déposer : montant à déposer dans votre compte bancaire</li>
                                        <li>Opérateur : MTN Cameroun ou Orange Cameroun </li>
                                        <li>Téléphone : votre numéro de téléphone s’affichera  automatiquement en fonction du choix de l’opérateur</li>
                                        <li>Code secret : pour sécuriser la transaction. Il ne doit être divulgué à personne</li>
                                    </ul>",
    'deposit-operator-1-desc-2' => '<p>3- Après avoir rempli les champs et choisi MTN Cameroon SA</p>
                                    <p>4- cliquer sur « Procéder »</p>
                                    <p>5- cliquer sur « ok »</p> 
                                    <p>Vous devez saisir *126# et valider l’opération en saisissant le code PIN de votre compte mobile money</p>',
    'deposit-operator-1-desc-3' => '<p>Vous devez valider l’opération en saisissant le code PIN de votre compte mobile money</p>
                                    <p>6- Sortez de l’application et dirigez vous dans votre dialer </p>
                                    <p>Vous devez saisir *126# </p>
                                    <p>7- Saisir « 1 », ensuite cliquez sur « Envoyer »</p>
                                    <p>8- Saisir votre code PIN et cliquer sur « Envoyer »</p>',
    'deposit-operator-1-desc-4' => '<p>Après avoir validé votre code PIN, vous recevez le message de confirmation dans l’application</p>
                                    <p>8- Cliquez sur « Bien »</p>
                                    <p>Vous êtes redirigés vers la page des transactions récentes</p>',
    'deposit-operator-1-desc-5' => '<p>Retourner dans l’application Becon’bank</p>
                                    <p>Vous serez dirigés vers la Page des transactions récentes.</p>
                                    <p>L’opération est enregistrée avec succès</p>
                                    <p>9- Cliquer sur « Ok »</p>
                                    <p>10- Cliquer sur le symbole pour retourner à la page d’accueil</p>
                                    <p>À la fin de l’opération, vous recevez : </p>
                                    <p>un SMS de votre opérateur téléphone qui vous notifie du paiement de l’opération</p>
                                    <p>un SMS de becon’bank</p>
                                    <p>Et un mail de l’application Becon’Bank, qui vous notifie du dépôt d’argent dans votre compte bancaire</p>',
    'deposit-operator-2' => 'Avec Orange',
    'deposit-operator-2-desc-1' => '<p>Pour effectuer un dépôt, veuillez suivre les étapes suivantes :</p>
                                    <p>1- cliquer sur « Faire un dépôt », </p>
                                    <p>2- Remplir les champs</p>
                                    <ul>
                                        <li>Montant à déposer : montant à déposer dans votre compte bancaire</li>
                                        <li>Opérateur : MTN Cameroun ou Orange Cameroun </li>
                                        <li>Téléphone : votre numéro de téléphone s’affichera  automatiquement en fonction du choix de l’opérateur</li>
                                        <li>Code secret : pour sécuriser la transaction. Il ne doit être divulgué à personne</li>
                                    </ul>',
    'deposit-operator-2-desc-2' => '<p>3- Après avoir rempli les champs et choisi Orange Cameroon SA</p>
                                    <p>4- cliquer sur « Procéder »</p>
                                    <p>Les transactions avec l’opérateur Orange nécessitent un code de paiement qui permet de sécuriser l’opération</p>
                                    <p>Pour générer le code de paiement :</p>
                                    <ul>
                                        <li>Cliquer sur « ok » et sortez de l’application</li>
                                        <li>Taper le code #150*4*4# sur votre téléphone pour générer le code marchand</li>
                                    </ul>',
    'deposit-operator-2-desc-3' => '<p>6- aller dans votre dialer et Taper le code #150*4*4# sur votre téléphone pour générer le code marchand</p>
                                    <p>7- Saisir votre code secret orange money </p>
                                    <p>8- valider en appuyant sur « send »</p>
                                    <p>Après avoir cliqué sur « Send », Orange Cameroun vous envoie le code de paiement.</p>
                                    <p>9- Cliquer sur « OK »</p>',
    'deposit-operator-2-desc-4' => '<p>10- message du code de paiement envoyer par orange cameroun.</p>
                                    <p>- Copier votre code de paiement</p>
                                    <p>- Retourner dans l’application Becon’bank</p>
                                    <p>Vous serez dirigés vers la Page de confirmation du paiement</p>
                                    <p>11- Saisissez votre  numéro de téléphone</p>
                                    <p>12- Le code de paiement se met automatiquement</p>
                                    <p>13- Cliquez sur « Confirm »</p>
                                    <p>Vous avez la confirmation du paiement </p>',
    'deposit-operator-2-desc-5' => '<p>Confirmation du paiement</p>
                                    <p>14- Cliquez sur le symbole « X », pour quitter la page</p>
                                    <p>Vous êtes redirigés vers la page des transactions récentes</p>
                                    <p>L’opération est enregistrée avec succès</p>
                                    <p>15- Cliquez sur « Ok »</p>
                                    <p>16- Cliquer sur le symbole pour retourner à la page d’accueil</p>
                                    <p>À la fin de l’opération, vous recevez : </p>
                                    <p>un SMS de votre opérateur téléphone qui vous notifie du paiement de l’opération</p>
                                    <p>Un SMS de Becon’bank</p>
                                    <p>Et un mail de l’application Becon’Bank, qui vous notifie du dépôt d’argent dans votre compte bancaire</p>',
    'withdrawal-1-desc-1' => '<p>Pour effectuer un  Retrait d’argent vers mon compte mobile money , veuillez suivre les étapes suivantes :</p>
                                <p>1- cliquer sur « Faire un retrait », </p>
                                <p>2- Ensuite sélectionner « Vers mon compte Mobile Money »</p>
                                <p>Vous êtes redirigés vers la page de retrait</p>',
    'withdrawal-1-desc-2' => '<p>Page de retrait</p>
                                <p>3- Remplir les champs</p>
                                <ul>
                                    <li>Compte: sélectionner l’un de vos comptes</li>
                                    <li>Nom complet</li>
                                    <li>Opérateur : le choix de l’opérateur met automatiquement votre numéro de téléphone</li>
                                    <li>Montant : montant à retirer de votre compte bancaire vers votre compte mobile money</li>
                                    <li>Code secret : pour sécuriser la transaction. Il ne doit être divulgué à personne</li>
                                </ul>
                                <p>Après avoir rempli les champs</p>
                                <p>4- cliquer sur « Procéder »</p>
                                <p>L’opération est enregistrée avec succès</p>',
    'withdrawal-1-desc-3' => '<p>L’opération est enregistrée avec succès</p>
                                <p>5- Cliquer sur « ok »</p>
                                <p>6- L’opération passe au statut « Unconfirmed » en attendant la validation de l’EMF/banque</p>
                                <p>7- Pour retourner à la page d’accueil, cliquez sur le symbole retour</p>',
    'withdrawal-2-desc-1' => '<p>Pour effectuer un  Retrait d’argent vers un autre numéro de téléphone , veuillez suivre les étapes suivantes :</p>
                                <p>1- cliquer sur « Faire un retrait », </p>
                                <p>2- Ensuite sélectionner « Vers un autre compte »</p>',
    'withdrawal-2-desc-2' => '<p>Page de retrait</p>
                                <p>3- Remplir les champs</p>
                                <ul>
                                    <li>Compte: sélectionner l’un de vos comptes</li>
                                    <li>Nom complet: votre nom</li>
                                    <li>Opérateur : MTN Cameroun ou Orange Cameroun</li>
                                    <li>Nom complet du récepteur: nom de votre bénéficiaire</li>
                                    <li>Téléphone récepteur : le numéro de téléphone du bénéficiaire</li>
                                    <li>Montant : montant à retirer de votre compte bancaire vers le compte mobile money</li>
                                    <li>Code secret : pour sécuriser la transaction. Il ne doit être divulgué à personne</li>
                                </ul>',
    'withdrawal-2-desc-3' => '<p>Après avoir rempli les champs</p>
                                <p>4- cliquer sur « Procéder »</p>
                                <p>L’opération est enregistrée avec succès</p>
                                <p>5- Cliquer sur « ok »</p>
                                <p>6- L’opération passe au statut « Unconfirmed » en attendant la validation de l’EMF/banque</p>
                                <p>7- cliquer sur le symbole pour retourner sur la page d’accueil.</p>',
    'transfer-desc-1' => '<p>La fonctionnalité « Faire un transfert » permet d’effectuer un transfert d’argent de votre compte bancaire vers un autre compte bancaire. </p>
                                <p>Pour accéder à cette fonctionnalité, veuillez suivre les étapes suivantes :</p>
                                <p>1- cliquer sur « Faire un transfert »,</p>
                                <p>Vous êtes redirigés vers la page de transfert</p>',
    'transfer-desc-2' => '<p>Page de transfert</p>
                                <p>2- Remplir les champs</p>
                                <ul>
                                    <li>Compte: sélectionner l’un de vos compte</li>
                                    <li>Nom complet: votre nom</li>
                                    <li>Nom(s) et prénom(s) complet: de votre bénéficiaire</li>
                                    <li>Numéro de compte récepteur : le numéro de compte du bénéficiaire</li>
                                    <li>Montant: montant à transférer</li>
                                    <li>Code secret : pour sécuriser la transaction. Il ne doit être divulgué à personne</li>
                                </ul>
                                <p>Après avoir rempli les champs</p>
                                <p>3- cliquer sur « Procéder »</p>
                                <p>L’opération est enregistrée avec succès</p>',
    'transfer-desc-3' => '<p>L’opération est enregistrée avec succès</p>
                                <p>4- Cliquer sur « ok »</p>
                                <p>5- L’opération passe au statut « Unconfirmed » en attendant la validation de l’EMF</p>
                                <p>6- cliquer sur le symbole pour avoir les détails de la transaction</p>
                                <p>7- Pour retourner à la page d’accueil, cliquez sur le symbole retour</p>
                                <p>Sélectionner votre compte bancaire pour lequel, vous souhaitez afficher les transactions récentes</p>',
    'transfer-desc-4' => '<p>La fonctionnalité « Retrait en agence » permet d’effectuer un transfert d’argent pour le retirer dans une agence EMF/Banques.</p>
                                <p>Pour accéder à cette fonctionnalité, veuillez suivre les étapes suivantes :</p>
                                <p>1- cliquer sur « Faire un transfert »,</p>
                                <p>Vous êtes redirigés vers la page de transfert</p>',
    'transfer-desc-5' => '<p>Page de transfert</p>
                                <p>2- Remplir les champs</p>
                                <ul>
                                    <li>Compte: sélectionner l’un de vos comptes</li>
                                    <li>Nom(s) et prénom(s) complet du bénéficiaire </li>
                                    <li>Opérateur : MTN Cameroun ou Orange Cameroun </li>
                                    <li>Téléphone : numéro de téléphone du bénéficiaire</li>
                                    <li>Montant : montant à transférer</li>
                                    <li>Mot de passe : le mot de passe doit être communiquer au bénéficiaire </li>
                                    <li>Code secret : pour sécuriser la transaction. Il ne doit être divulgué à personne</li>
                                    <p>Après avoir rempli les champs</p>
                                    <p>3- cliquer sur « Procéder »</p>
                                    <li>L’opération est enregistrée avec succès</li>
                                </ul>
                                <p>Vous avez la possibilité d’envoyer les coordonnées du transfert au bénéficiaire </p>',
    'transfer-desc-6' => '<p>Après avoir cliqué sur « Procéder » vous avez la possibilité d’envoyer les coordonnées du transfert au bénéficiaire</p>
                                <ul>
                                    <li>Cliquer sur « Non ça va » si vous ne souhaiter pas notifier le bénéficiaire du transfert </li>
                                    <li>Cliquer sur « Oui  » pour notifier le bénéficiaire </li>
                                    <li>En cliquant sur « Oui », vous devriez choisir l’application par laquelle vous souhaiter notifier le bénéficiaire</li>
                                </ul>',
    'transfer-desc-7' => '<p>Page des transactions récentes.</p>
                                <p>L’opération est enregistrée avec succès</p>
                                <p>4- Cliquer sur « ok »</p>
                                <p>5- L’opération passe au statut « Unconfirmed » en attendant la validation de l’EMF</p>
                                <p>6- Pour retourner à la page d’accueil, cliquez sur le symbole retour</p>',
    'transaction-desc-1' => '<p>Pour visualiser l’historique de ses transactions dans l’application mobile, veuillez suivre les étapes suivantes :</p>
                                <p>1- Cliquer sur le symbole Menu</p>
                                <p>2- page du menu</p>
                                <p>Vous avez l’historique des :</p>
                                <p>3. Completed transactions : Transactions validées par l’EMF/banque</p>
                                <p>4. Pending transactions : Transactions en attentes de validation</p>
                                <p>5. Failed transactions : Transactions rejetées</p>',
    'transaction-desc-2' => '<p>Pour visualiser l’historique des transactions validées, veuillez suivre les étapes suivantes :</p>
                                <p>1- Cliquer sur le symbole Menu</p>
                                <p>2- cliquer sur « Completed transactions »</p>
                                <p>Vous êtes redirigés vers la page des transactions validées</p>',
    'transaction-desc-3' => '<p>Page des transactions validées</p>
                                <p>1- cliquer sur le symbole pour afficher le menu</p>
                                <p>2- cliquer sur le symbole pour sélectionner un autre compte afin d’afficher son historique.</p>
                                <p>3- cliquer sur le symbole pour retourner à la page d’accueil</p>
                                <p>4- cliquer sur le symbole pour afficher les détails de l’opération.</p>',
    'profil-desc-1' => '<p>Apres avoir télécharger l’application sur Play store, veuillez suivre les étapes suivantes pour se connecter à l’application mobile :</p>
                                <p>1- Aller dans le menu de votre téléphone et ouvrez l’application Becon’Bank</p>
                                <p>2- Saisir votre adresse mail ou votre numéro de téléphone</p>
                                <p>3- Saisir votre mot de passe</p>
                                <p>4- cliquer sur « Log in »</p>
                                <p>Vous êtes redirigés vers la page d’accueil de l’application mobile</p>',
    'profil-desc-2' => '<p>Pour visualiser votre profil, vous avez 02 possibilités :</p>
                                <p><u>1ère possibilité : </u></p>
                                <p>1- Cliquer sur le symbole Menu</p>
                                <p>2- Cliquer sur « My profile »</p>
                                <p><u>2ème possibilité: </u></p>
                                <p>3- Cliquer sur « Mon profil »</p>
                                <p>Vous êtes redirigés vers la Page d’accès du profil</p>',
    'profil-desc-3' => '<p>Page d’accès du profil</p>
                        <p>Pour Modifier le profil, veuillez modifier les informations à votre convenance</p>
                        <p>1- ensuite cliquer sur « Valider »</p>
                        <p>Votre profil est mis à jour avec succès</p>
                        <p>2-Cliquer sur ok</p>',
    'profil-desc-4' => '<p>Page d’accès du profil</p>
                            <p>1- Cliquer sur « Password »</p>
                            <p>Remplir les champs</p>
                            <p>2- Cliquer sur « Valider »</p>
                            <p>Mot de passe est changé avec succès</p>',
    'profil-desc-5' => '<p>Page d’accès du profil</p>
                            <p>1- Cliquer sur « Code secret »</p>
                            <p>Remplir les champs</p>
                            <p>2- Cliquer sur « Valider »</p>
                            <p>Code secret modifié avec succès</p>',
    'profil-desc-6' => '<p>Pour sortir de l’application, veuillez suivre les étapes suivantes :</p>
                            <p>1- Cliquer sur le symbole Menu</p>
                            <p>2- Cliquer sur « Exit app »</p>
                            <p>3- Cliquer sur « Yes »</p>
                            <p>La fonctionnalité « Exit app » permet de quitter l’application</p>',
    'profil-desc-7' => '<div class="" style=" ">
                            <p>Pour se déconnecter, veuillez suivre les étapes suivantes :</p>
                            <p>1- Cliquer sur le symbole Menu</p>
                            <p>2- Cliquer sur « Logout »</p>
                            <p>Vous êtes redirigés vers la page de connexion</p>',

];
