<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Pagination Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the paginator library to build
    | the simple pagination links. You are free to change them to anything
    | you want to customize your views to better match your application.
    |
    */


    'title-1' => 'Liste de EMF et Banques',
    'title-2' => 'Partenaires',
    'structure' => 'Microfinance Academy',
    'numero' => '+237 969 797 789 653',
    'text' => '',

];
