<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Pagination Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the paginator library to build
    | the simple pagination links. You are free to change them to anything
    | you want to customize your views to better match your application.
    |
    */

    "message-title" => "Leave us a message",
    "contact" => "Contact Us",
    "contact-desc" => "Feel free to ask for details, don't save any questions!",
    "name-form" => "Full Name",
    "email-form" => "Email Address",
    "subjet-form" => "subjet",
    "phone-form" => "Phone",
    "message-form" => "Message",
    "btn-envoie" => "Send",
    "office" => "Our Office",
    "address" => "Address: Akwa, Rue Ancien Sonel",
    "phone" => "Phone: 652812315",
    "email" => "Email:",
    "email-desc" => "contact@beconbank.com",
    "hours" => "Business Hours",
    "heure-1" => "Monday - Friday - 9am to 6pm",
    "heure-2" => "Saturday - 9am to 2pm",
    "heure-3" => "Sunday - Closed",
    "get-touch" => "Get in Touch",
    "get-touch-desc" => "",
];