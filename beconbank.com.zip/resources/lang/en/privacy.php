<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Pagination Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the paginator library to build
    | the simple pagination links. You are free to change them to anything
    | you want to customize your views to better match your application.
    |
    */

    'entete' => 'Privacy',
    'title' => 'Privacy policy for Becon\'Bank',
    'article-1' => 'Article 1 - Important information',
    'article-1-desc' => 'At INIMOV SAS, we recognize the importance of the privacy and security of our customers\' personal information. We appreciate the trust you place in us to protect your personal informations and respect your right to privacy. While new technologies have radically changed the way information is collected, used and stored, maintaining customer confidence and privacy at INIMOV SAS remains a goal fundamental. We believe it is important to make it clear to our customers how Becon\'Bank collects, uses and shares information, the benefits of such use and the protections put in place against unauthorized access and use. We respect your privacy and the confidentiality of your personal information, and we appreciate the opportunity to do business with you.',
    'article-1-desc-2' => 'We will collect, transfer, process and store your personal information only with your express permission, unless required by law, and will use this information only for the legal purpose for which it is required. We will disclose the specific purpose for which we use, request and store your personal information. We will also keep a record of this personal information and the specific purpose for which we collect it. We will not use your personal information for purposes other than those we have disclosed to you, unless you give us your explicit consent to that effect, or we are authorized to do so by law.',
    'article-2' => 'Article 2 - Data collected on Becon\'Bank (mobile application and website)',
    'article-2-desc' => 'We do collect information about you when you register on our mobile app or website. We do not collect any particular category of personal data about you (this includes details about your race or ethnicity, religious or philosophical beliefs, sex life, sexual orientation, opinions your membership in a union, information about your health, as well as your genetic and biometric data). We also do not collect information on criminal convictions and offences.',
    'desc-2' => 'We will collect, store and use the following categories of personal information about you as follows:',
    'donnée-1' => 'Identity data, ',
    'donnée-1-desc' => 'including personal details such as name and title.',
    'donnée-2' => 'Financial data, ',
    'donnée-2-desc' => 'including bank account details and other banking information.',
    'donnée-3' => 'Transaction data, ',
    'donnée-3-desc' => 'including your billing history, the products and services you use, and everything related to your account.',
    'donnée-4' => 'Profile data, ',
    'donnée-4-desc' => 'including the information you provided us in our communications, the information you provided to us during your participation in surveys.',
    'donnée-5' => 'Marketing and communication data, ',
    'donnée-5-desc' => ', including your marketing reception preferences from us and third parties, and your communication preferences.',
    'desc-3' => 'It is important that the personal data we hold about you is accurate and up to date. Please let us know if your personal data changes during your relationship with us.',
    'article-3' => 'Article 3 - Data Collection Method ',
    'article-3-desc' => ' We collect personal information about you when you subscribe to the Becon\'Bank service, via a form you fill out, you provide us with your identity, contact, financial and transaction data.  ',
    'article-4' => 'Article 4 - Use of collected data',
    'article-4-desc' => 'We will only use your personal information when the law allows us to do so. More often than not, we will use your personal information in the following cases:',
    'cas-1' => 'We use the data we have collected to authenticate you and allow access to our services on the website and mobile app.',
    'cas-2' => 'We will contact you by email, SMS, phone call and other means via our services, including text messages and notifications. We will send you messages about the availability of our services, security or other service-related issues.',
    'cas-3' => 'We serve you personalized advertisements on and off our services. We target our customers\' ads on and off duty through various networks and ad exchanges, using data from and outside our service\'s advertising technologies, as well as information from advertising partners.',
    'cas-4' => 'We use the data to investigate, respond and resolve complaints and service issues.',
    'cas-5' => 'We use your data (including your communications) if we deem it necessary for security purposes or to investigate possible fraud or other violations of our User Contract or this Privacy Policy and/or attempt to harm our Members or our visitors.',
    'article-5' => 'Article 5 - Data Security',
    'article-5-desc' => 'Protecting our solution and our users\' information is paramount to ensuring that customers in the brand, website and our mobile application have a secure experience and maintain the trust of our users. We have taken the following steps to protect your information.',
    'mesure-1' => 'The Publisher has put in place technical, administrative and physical protections to help protect against unauthorized access, use or disclosure of customer information we collect or store. ',
    'mesure-2' => 'We implement various security measures to maintain the security of your personal information when you enter, send or access your personal information.',
    'mesure-3' => 'Your personal information may be accessible to authorized persons with special access rights to such systems and are required to keep the information confidential. Information such as PINs and passwords are not available to our authorized staff.',
    'mesure-4' => 'The Publisher informs you that your data may be disclosed under a law, regulation or a decision of a competent regulatory or judicial authority or, if necessary, for the publisher\'s purposes, to preserve its rights and interests.',
    'article-6' => 'Article 6 - Sharing your collected data',
    'article-6-desc' => 'When you use or interact with our services, you consent to the processing, sharing, transfer and use of your information in accordance with this privacy policy. The Publisher strives to comply with all applicable data protection and privacy regulations, including EU general data protection regulations.',
    'article-6-desc-1' => 'To provide you with our services, your personal information may be transferred to other partners to process and store the data in accordance with our privacy policy and to provide you with products and services. We may transfer your data to affiliates or partners, including outsourced data processing on behalf of the Publisher.',
    'article-6-desc-2' => 'In all sharing agreements, the Publisher requires its service providers and business partners to retain this information in accordance with strict privacy regulations and prohibits it from disclosing it to whom whether for other purposes.',
    'article-7' => 'Article 7 - User Rights',
    'point-1' => 'Data retention',
    'point-1-desc' => 'We keep most of your personal data as long as your account is active. We keep the personal data you have provided during the duration of your account or if necessary, to provide you with our services.',
    'point-2' => 'Access and control rights to your personal data',
    'point-2-desc' => 'You can access your personal data from our services when you follow our procedures regarding the requests of the people concerned. You can always edit or update your personal data using the appropriate menus on the website or mobile app.',
    'article-7-desc' => 'When you wish to opt out of this service, you must send a request to your microfinance institution, and it in return will contact us to validate the processing request. A deactivated account can always keep a transaction history on our systems in accordance with the Bank\'s financial laws and data retention policies.',

];
