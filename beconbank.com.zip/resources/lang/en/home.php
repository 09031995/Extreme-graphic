<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Pagination Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the paginator library to build
    | the simple pagination links. You are free to change them to anything
    | you want to customize your views to better match your application.
    |
    */

    'slide-1' => ' Be connected with your Bank',
    'text-1' => 'Be connected with',
    'text-2' => 'your Bank',
    'next' => 'Next &raquo;',
    "main-features" => "Why Becon'bank?",
    "feature-1" => "View your account balance in real time",
    "feature-1-desc" => "In a few clicks, you can view your bank balance via a computer, tablet or smartphone",
    "feature-2" => "View transaction history",
    "feature-2-desc" => "With Becon'Bank you can view the history of all your transactions",
    "feature-3" => "Make deposits and withdrawals via mobile accounts",
    "feature-3-desc" => "Becon'bank is a digital platform that links microfinance institutions and banks with their customers, enabling them to make financial transactions remotely from their mobile phone ",
    "feature-4" => "Find the different branch of your Microfinance institutions / Banks",
    "feature-4-desc" => "Becon'bank lists the branch of microfinance institutions / banks to ease your life",
    "feature-5" => "Carry out the transactions to one of your relatives on his mobile money account, on his bank account or through a withdrawal in an agency",
    "feature-5-desc" => "Make instant cash transfers to third-party accounts or branch withdrawals",
    "feature-6" => "Management all your account in one application :",
    "feature-6-desc" => "Beconbank allows you to carry out banking transaction with all your accounts the same application",
    "beconbank-advantages" => "Becon'Bank advantages",
    "advantage-1" => "Reduction of queues in agencies",
    "advantage-2" => "Reduced risk of money theft",
    "advantage-3" => "24/7 access to the platform",
    "advantage-4" => "Notification by SMS / Email",
    "advantage-5" => "Access to a set of services: withdrawal, deposit, money transfer",
    "advantage-6" => "Visibility of your balance in real time",
    "how-it-works" => "How it works",
    "how-it-works-1" => "Get in touch with your customer advisor, who will assist you with service activation and application download",
    "how-it-works-2" => "Connect to the Becon'bank platform. Carry out your transactions: deposit, withdrawal, transfer of money",
    "how-it-works-3" => "Discover our network of partners",
];
