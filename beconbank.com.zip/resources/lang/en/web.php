<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Pagination Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the paginator library to build
    | the simple pagination links. You are free to change them to anything
    | you want to customize your views to better match your application.
    |
    */

    'cash-deposit' => 'Cash deposit',
    'cash-deposit-1' => 'Cash deposit with MTN',
    'cash-deposit-2' => 'Cash deposit with Orange',
    'cash-transfer-1' => 'Cash Transfer',
    'cash-transfer-2' => 'Withdrawal in agencies',
    'cash-withdrawal' => 'Cash withdrawal',
    'cash-withdrawal-1' => 'Withdrawal with my phone number',
    'cash-withdrawal-2' => 'Withdrawal with another phone number',
    'customer-setup' => "Customer setup",
    'customer-title-1' => 'Connect to the mobile app',
    'customer-title-2' => 'To view the Profile',
    'customer-title-3' => 'Edit Profile',
    'customer-title-4' => 'Change Password',
    'customer-title-5' => 'Change secret code',
    'customer-title-6' => 'Exit app',
    'customer-title-7' => 'Logout',
    'transaction-management' => "Transaction management",
    'deposit-operator-1' => 'With MTN',
    'deposit-operator-1-desc-1' => "<p>In Becon'bank, the deposit of money allows you to put money into your bank account through your mobile money account</p>
                                    <p>To make a Cash Deposit, please follow these steps:</p>
                                    <p>1- click on “Operations” then select “Cash Deposit”</p>
                                    <p>Or you can click on </p>
                                    <p>2- “Cash Deposit”</p>",
    'deposit-operator-1-desc-2' => '<p>3- fill in the fields, and choose “MTN Cameroon SA” in the “Operator’s choice” field then click “Validate”</p>
                                    <p>4- you will receive a message on your mobile from your mobile operator to confirm the operation</p>',
    'deposit-operator-1-desc-3' => '<p>5- After validating the transaction on your mobile pone, you will receive another message from your phone operator </p>
                                    <p>6- and an email from Becon’bank</p>
                                    <p>7-check that the transaction’s status changes to “Confirmed”</p>',
    'deposit-operator-2' => 'With Orange',
    'deposit-operator-2-desc-1' => '<p>In Becon\'bank, the deposit of money allows you to put money into your bank account through your mobile money account</p>
                                    <p>To make a Cash Deposit, please follow these steps:</p>
                                    <p>1- click on “Operations” then select “Cash Deposit”</p>
                                    <p>Or you can click on </p>
                                    <p>2- “Cash Deposit”</p>',
    'deposit-operator-2-desc-2' => '<p>3- fill in the fields, and choose “Orange Cameroon SA” in the “Operator’s choice” field then click “Validate” </p>
                                    <p>Enter #150*4*4# on your phone to generate payment code</p>
                                    <p>4- You will receive the payment code from your operator via SMS The payment code is a security code put by Orange Cameroon that helps secure cash withdrawals</p>',
    'deposit-operator-2-desc-3' => '5- fill out the fields and click « Confirm »
                                      <ul>
                                        <li>you will receive a message from your phone operator in your phone</li>
                                        <li>SMS and an email from Becon’bank</li>
                                      </ul>',
    'withdrawal-1-desc-1' => '<p>Withdrawal of money to another phone number you withdraw money from your bank account to the mobile money account of a loved one.</p>
                                <p>To withdraw cash to your phone number you have 02 options: </p>
                                <p><u>1st possibility: </u></p>
                                <p>1- click “Operations”</p>
                                <p>2- after select “Cash Withdrawal”</p>
                                <p><u>2nd possibility:</u></p>
                                <p>1- click on “Cash Withdrawal”</p>
                                <p>2- then on “Cash Withdrawal to my phone number”</p>',
    'withdrawal-1-desc-2' => '<p>3- fill in fields </p>
                                <p>Client: votre nom complet</p>
                                <p>Choose an Account: you have to choose one of your accounts with which you want to make the transaction</p>
                                <p>Operator’s choice: you have to choose between the operator Orange et MTN</p>
                                <p>Phone number: your phone number</p>
                                <p>Amount to withdraw Code secret</p>
                                <p>6- and click on “Withdraw Money”</p>
                                <p>7- the operation is registered with the “Unconfirmed” status waiting validation from the Administration</p>',
    'withdrawal-2-desc-1' => '<p>Withdrawal of money to another phone number you withdraw money from your bank account to the mobile money account of one of your loved ones.</p>
                                <p>To withdraw cash to another phone number, you have 02 options:</p>
                                <p><u>1st possibility: </u></p>
                                <p>1- click “Operations”</p>
                                <p>2- after select “Withdrawing to another phone number” </p>
                                <p>2nd possibility:</p>
                                <p>Or you can click on:</p>
                                <p>1- “Cash Withdrawal”</p>
                                <p>2- then on “Withdrawing to another phone number”</p>',
    'withdrawal-2-desc-2' => '<p>3- fill in fields </p>
                                <p>Client: your name</p>
                                <p>Choose an Account: you have to choose one of your accounts with which you want to make the transaction</p>
                                <p>Operator’s choice: you have to choose between the operator Orange et MTN</p>
                                <p>Pone number: Phone number you want to send money to</p>
                                <P>Receiver name: your beneficiary\'s name</P>
                                <p>Amount to withdraw : amount you want to withdraw</p>
                                <p><strong>Code secret</strong></p>
                                <p>6- click on “Withdraw Money”</p>
                                <p>7- the operation is registered with the “Unconfirmed” status waiting validation from the Administration</p>',
    'transfer-desc-1' => '<p>The "transfer to an account" feature allows you to transfer money from your bank account to another bank account.</p>
                                <p>Bank accounts must be domiciled in the same financial institution</p>
                                <p>To transfer money to another account, you have 02 option:</p>
                                <p>1st possibility: </p>
                                <p>1- click “Operations”</p>
                                <p>2- after select “Account Transfer </p>
                                <p>2nd possibility:</p>
                                <p>3- click"Transfer",</p>
                                <p>4- Then click“Account transfer"</p>',
    'transfer-desc-2' => '<p>5- fill in the fields</p>
                                <p>My acount: you have to choose one of your accounts with which you want to make the transaction</p>
                                <p>Account’s number receiver: bank account number in which you want to transfer money</p>
                                <p>Receiver name: The full name of the owner of the beneficiary account</p>
                                <p>Amount to transfer</p>
                                <p>Secret code : your secret code</p>
                                <p>6- click on “Transfer Money”</p>
                                <p>7- the transaction is registered with the “Unconfirmed” status, awaiting for the Microfinance Institution / Banks validation.</p>',
    'transfer-desc-3' => '<p>The “Withdrawal in Agency” feature allows you to send money to someone who doesn\'t have either a bank account or an account domiciled in your financial institution</p>
                                <p>To access this feature, you have 02 possibilities:</p>
                                <p><u>1st possibility</u></p>
                                <p>1- click “Operations”</p>
                                <p>2- after select “Withdrawal in Agency”</p>
                                <p>2nd possibility:</p>
                                <p>1- click on « Transferts »</p>
                                <p>2- then click on « For Withdrawal in Agency »</p>',
    'transfer-desc-4' => '<p>3- fill in the fields and click on “Save”</p>
                          <p>4- the transaction is registered with the “Unconfirmed” status, awaiting for the Microfinance Institution / Banks validation.</p>
                          <p>5- Fill the fields</p>
                          <ul>
                            <li>slip number : to communicate to your beneficiary</li>
                            <li>Account Choice: choose one of your accounts with which you want to make the transaction</li>
                            <li>Last Name (s) and first name: the full name of the person to whom you send money Number</li>
                            <li>Telephone number: Recipient\'s phone number </li>
                            <li>Amount: the amount you want to send </li>
                            <li>Password: your secret code to communicate to your beneficiary </li>
                          </ul>
                          <p>6- click "Save"</p>
                          <p>7- the operation goes to "unconfirmed" status for validation by the EMF.</p>',
    'transaction-desc-1' => '<p>The transaction management feature is divided in to 2 elements :</p>
                                <ul>
                                    <li>Pending Transaction : shows all transactions awaiting validation by the Administration</li>
                                    <li>History: shows all of your transactions (confirmed, validated, paid for)</li>
                                </ul>',
    'transaction-desc-2' => '<p>The “Pending Transaction” feature allows you to view transactions that must be confirmed by the microfinance institution.</p>
                                <p>To access this feature, please follow these steps:</p>
                                <p>1- click on “Transaction management”</p>
                                <p>2- click on “Pending Transactions”</p>
                                <p>3- you have access to the history</p>',
    'transaction-desc-3' => '<p>The “History” feature allows you to visualize all customer transactions (deposit, withdrawal, transfer, validated, unconfirmed).</p>
                                <p>To access this feature, please follow these steps:</p>
                                <p>1- click on “Transaction Management”</p>
                                <p>2- click on “History”</p>
                                <p>3- you have access to the history</p>',
    'transaction-desc-4' => '<p>You have the ability to view your transactions based on your different accounts</p>
                                <p>1- go in "dashboard" </p>
                                <p>2- select an account</p>',
    'transaction-desc-5' => '3- You have the balance and recent transactions of the selected account',
    'profil-desc-1' => '<p>After the creation of the customer by the Microfinance Institution / Bank, the customer receives a confirmation email.</p>
                                <p>1- copy your default password</p>
                                <p>2- click “click here to verify your account”</p>
                                <p>You will be redirected to the login page.</p>',
    'profil-desc-2' => '<p>Login page</p>
                                <p>Please enter your email or your number phone and your password</p>
                                <p>3- click “Sign in”</p>',
    'profil-desc-3' => '<ul>
                            <li>Dashboard: Shows balance and recent transactions</li>
                            <li>Operations: allows transactions to be made (deposit, withdrawal, transfer)</li>
                            <li>Transaction management: allows you to view all transactions made in your account</li>
                            <li>Money deposit: allows you to make a deposit from the mobile money account to the microfinance institution/Bank account</li>
                            <li>Cash withdrawal: allows you to withdraw money from the microfinance institution/bank account to the mobile money account</li>
                            <li>Transfers: allows transfers to another account of the Microfinance Institution/Bank and withdraw to an agency</li>
                        </ul>',
    'profil-desc-4' => '<p>To change language, please follow these steps:</p>
                            <p>1- click on the flag icon</p>
                            <p>2- select the language of your choice.</p>',
    'profil-desc-5' => '<p>To “View the Profile”, follow these steps : </p>
                            <p>1- click on your name</p>
                            <p>2- click on “Profile”</p>
                            <p>You will be redirected to your profile</p>',
    'profil-desc-6' => '<p>To change your account password, follow these steps:</p>
                            <p>1- click on your name</p>
                            <p>2- click on “Change Password”</p>
                            <p>3- fill in the fields and click on “Submit”</p>',
    'profil-desc-7' => '<div class="" style=" ">
                            <p>Secret code is used to secure transactions.</p>
                            <p>To change your account secret code, follow these steps: </p>
                            <p>1- click on your name</p>
                            <p>2- click “Change secret code”</p>
                            <p>3- fill in the fields and click on “Submit”</p>',
    'profil-desc-8' => '<p>“To Sign Out” please follow these steps:</p>
                            <p>1- click on your name</p>
                            <p>2- click “Disconnect”</p>
                            <p>3- you will be redirected to the home page</p>',
];
