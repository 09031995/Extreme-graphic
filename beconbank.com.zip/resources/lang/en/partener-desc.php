<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Pagination Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the paginator library to build
    | the simple pagination links. You are free to change them to anything
    | you want to customize your views to better match your application.
    |
    */

    'title' => 'MICROFINANCE ACADEMY',
    'texte' => 'Microfinance Academy is an organization expert in thessistance of the microfinance and micro-enterprise sector in Africa through studies, training, assistance technical advice, advice, etc. Microfinance Academy is a chartered partner with the Consultative Group to Assist the Poor (CGAP- World Bank). The latter has been supporting the institution through a programme to strengthen the capacity of its trainers for nearly fifteen years. ',
    'title-2' => 'The organization mainly works with: ',
    'liste-1' => 'Microfinance institutions and their networks',
    'liste-2' => 'Regulators',
    'liste-3' => 'Donors',
    'liste-4' => 'Consulting firms',
    'liste-5' => 'Conventional commercial banks',
    'liste-6' => 'The ministries in charge of microfinance and micro-enterprise.',
    'title-3' => 'Microfinance Academy aims to:',
    'liste-7' => 'To increase the skills of microfinance and micro-enterprise players in Africa.',
    'liste-8' => 'Supporting microfinance institutions on the path to innovation and action research.',
    'liste-9' => 'Provide microfinance institutions and micro-enterprises with information on the donors who support the microfinance and micro-enterprise sector around the world.',
    'liste-10' => 'Gathering and disseminating information on management practices to microfinance institutions and micro-enterprise',

];
