<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Pagination Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the paginator library to build
    | the simple pagination links. You are free to change them to anything
    | you want to customize your views to better match your application.
    |
    */

    "connected-relationship" => "Connected relationship with his customers",
    "get-new-customers" => "Get new customers quickly, Retain your current customers",
    "services-available" => "Why Becon'bank?",
    "service-1" => "Customer management",
    "service-2" => "Transaction validation",
    "service-3" => "Importing Information System Data to Becon'bank",
    "service-4" => "Additional service",
    "service-5" => "Reports and Analytics",
    "service-6" => "Administration",
    "beconbank-advantages" => "Becon'Bank advantages",
    "advantage-1" => "Customer satisfaction",
    "advantage-1-desc" => "Improve the customer satisfaction: by providing them with new low-rates services",
    "advantage-2" => "Operational efficiency",
    "advantage-2-desc" => "Enhance operational efficiency of microfinance institutions/banks by new real-time features (reporting, etc.) and worthful client data",
    "advantage-3" => "IMF/Banks employees",
    "advantage-3-desc" => "Concentrate IMF/Banks employees to added value activities : by avoiding over-solicitations from customers at the local offices",
    "advantage-4" => "Customer's actions more fluid",
    "advantage-4-desc" => "Make your customer's actions more fluid to ensure their loyalty",
    "advantage-5" => "Digital financial institution",
    "advantage-5-desc" => "Become a digital financial institution: by reducing the risks and losses of money thefts of your customers and collectors, increasing the visibility of your trademark brand",
    "become-partner" => "Become a partner EMF/Bank",
    "fill-form" => "Fill in the form",
    "fill-form-desc" => "We contact you to finalize the creation of your partner account",
    "company-name" => "Company Name",
    "activity-area" => "Activity area",
    "form-name" => "Name of the contact",
    "form-phone" => "Phone Number",
    "email" => "E-mail",
    "btn-submit" => "Send a message",
    "become-partner-2" => "Strategy for launching the solution",
    "become-partner-2-desc" => "Receive your launch kit. We will make sure that you have all the supports for launching the solution",
    "become-partner-3" => "Get your customers to join Becon'Bank",
    "become-partner-3-desc" => "Existing or new customers will be able to trade from the Becon'bank platform",
    "become-partner-4" => "Follow your operations and those of your clients",
    "become-partner-4-desc" => "Get real-time visibility into your EMF account. Have a report of all the transactions of your customers.",
];
