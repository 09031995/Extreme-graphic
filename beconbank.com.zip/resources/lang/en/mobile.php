<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Pagination Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the paginator library to build
    | the simple pagination links. You are free to change them to anything
    | you want to customize your views to better match your application.
    |
    */

    'cash-deposit' => 'Cash deposit',
    'cash-deposit-1' => 'Cash deposit with MTN',
    'cash-deposit-2' => 'Cash deposit with Orange',
    'cash-transfer-1' => 'Cash Transfer',
    'cash-transfer-2' => 'Withdrawal in agencies',
    'cash-withdrawal' => 'Cash withdrawal',
    'cash-withdrawal-1' => 'Withdrawal with my phone number',
    'cash-withdrawal-2' => 'Withdrawal with another phone number',
    'customer-setup' => "Customer setup",
    'customer-title-1' => 'Connect to the mobile app',
    'customer-title-2' => 'To view the Profile',
    'customer-title-3' => 'Edit Profile',
    'customer-title-4' => 'Change Password',
    'customer-title-5' => 'Change secret code',
    'customer-title-6' => 'Exit app',
    'customer-title-7' => 'Logout',
    'transaction-management' => "Transaction management",
    'deposit-operator-1' => 'With MTN',
    'deposit-operator-1-desc-1' => "<p>To make a Cash Deposit, please follow these steps:</p>
                                    <p>1- click on “Faire un dépôt”</p>
                                    <p>You are redirected to the deposit page</p>
                                    <p>2- fill in the fields</p>
                                    <ul>
                                        <li>Compte: Select one of your accounts</li>
                                        <li>Montant à déposer : amount to deposit into your bank account</li>
                                        <li>Opérateur : MTN Cameroon or Orange Cameroon</li>
                                        <li>Téléphone : your phone number will automatically appear depending on the operator's choice</li>
                                        <li>Code secret : to secure the transaction. It should not be disclosed to anyone</li>
                                    </ul>",
    'deposit-operator-1-desc-2' => '<p>3- After filling the fields and choosing MTN Cameroon SA</p>
                                    <p>4- click on « Procéder »</p>
                                    <p>5- click on « ok » </p> 
                                    <p>You must enter *126# and validate the transaction by entering the PIN of your mobile money account</p>',
    'deposit-operator-1-desc-3' => '<p>You must validate the transaction by entering the PIN of your mobile money account</p>
                                    <p>6- Get out of the app and head into your dialer</p>
                                    <p>You\'ve got to grab *126 #</p>
                                    <p>7- Enter "1," then click "Send"</p>
                                    <p>8- Enter your PIN and click "Send"</p>',
    'deposit-operator-1-desc-4' => '<p>After you validate your PIN, you receive the confirmation message in the app</p>
                                    <p>8- clik on « Bien »</p>
                                    <p>You are redirected to the recent transactions page</p>',
    'deposit-operator-1-desc-5' => '<p>Return to the Becon\'bank app</p>
                                    <p>You\'ll be directed to the Recent Transactions Page.</p>
                                    <p>The operation is successfully registered</p>
                                    <p>9- Click on « Ok »</p>
                                    <p>10- Click on the symbol to return to the home page</p>
                                    <p>At the end of the operation, you receive: </p>
                                    <p>an SMS from your phone operator that notifies you of the payment of the transaction</p>
                                    <p>an SMS from becon’bank</p>
                                    <p>And an email from the Becon\'Bank app, notifies you of the deposit of money in your bank account</p>',
    'deposit-operator-2' => 'Avec Orange',
    'deposit-operator-2-desc-1' => '<p>To make a Cash Deposit, please follow these steps:</p>
                                    <p>1- click on “Faire un dépôt”</p>
                                    <p>You are redirected to the deposit page</p>
                                    <p>2- fill in the fields</p>
                                    <ul>
                                        <li>Compte: Select one of your accounts</li>
                                        <li>Montant à déposer : amount to deposit into your bank account</li>
                                        <li>Opérateur : MTN Cameroon or Orange Cameroon</li>
                                        <li>Téléphone : your phone number will automatically appear depending on the operator\'s choice</li>
                                        <li>Code secret : to secure the transaction. It should not be disclosed to anyone</li>
                                    </ul>',
    'deposit-operator-2-desc-2' => '<p>3- After filling the fields and choosing Orange Cameroon SA</p>
                                    <p>4- click on « Procéder »</p>
                                    <p>Transactions with the Orange operator require a payment code that helps secure the transaction</p>
                                    <p>To generate the payment code:</p>
                                    <ul>
                                        <li>Click on « ok » and get out of the app</li>
                                        <li>Enter the #150*4*4# code on your phone to generate the merchant code</li>
                                    </ul>',
    'deposit-operator-2-desc-3' => '<p>6- go into your dialer and enter the code #150*4*4# to your phone to generate the merchant code</p>
                                    <p>7- Enter your secret code orange money</p>
                                    <p>8- validate by pressing « send »</p>
                                    <p>After clicking "Send," Orange Cameroon sends you the payment code. </p>
                                    <p>9- Click on « OK »</p>',
    'deposit-operator-2-desc-4' => '<p>10- payment code message send by orange cameroon.</p>
                                    <p>- Copy your payment code</p>
                                    <p>- Return to the Becon\'bank app</p>
                                    <p>You will be directed to the Payment Confirmation Page</p>
                                    <p>11- Enter your phone number</p>
                                    <p>12- Enter the payment code</p>
                                    <p>13- Click on « Confirm »</p>
                                    <p>You have confirmation of payment</p>',
    'deposit-operator-2-desc-5' => '<p>Confirmation du paiement</p>
                                    <p>14- Click the "X" symbol to leave the page</p>
                                    <p>You are redirected to the recent transactions page</p>
                                    <p>The operation is successfully registered</p>
                                    <p>15- Click on « Ok »</p>
                                    <p>16- Click on the symbol to return to the home page</p>
                                    <p>At the end of the operation, you receive: </p>
                                    <p>an SMS from your phone operator that notifies you of the payment of the transaction</p>
                                    <p>un SMS from becon’bank</p>
                                    <p>And an email from the Becon\'Bank app, notifies you of the deposit of money in your bank account</p>',
    'withdrawal-1-desc-1' => '<p>To withdraw cash to your phone number, Please follow the following steps:</p>
                                <p>1- Click on « Faire un retrait », </p>
                                <p>2- Select « Vers mon compte Mobile Money »</p>
                                <p>You are redirected to the withdrawal page</p>',
    'withdrawal-1-desc-2' => '<p>3- Fill the fields</p>
                                <ul>
                                    <li>Compte: Select one of your accounts</li>
                                    <li>Nom complet</li>
                                    <li>Opérateur : The choice of operator automatically puts your phone number</li>
                                    <li>Montant : amount to withdraw from your bank account to your mobile money account</li>
                                    <li>Code secret : to secure the transaction. It should not be disclosed to anyone</li>
                                </ul>
                                <p>After filling the fields</p>
                                <p>4- Click on « Procéder »</p>
                                <p>The operation is successfully registered</p>',
    'withdrawal-1-desc-3' => '<p>The operation is successfully registered</p>
                                <p>5- Click on « ok »</p>
                                <p>6- the operation is registered with the “Unconfirmed” status waiting validation from the Administration</p>
                                <p>7- Click on the symbol to return to the home page</p>',
    'withdrawal-2-desc-1' => '<p>To withdraw cash to another phone number, Please follow the following steps:</p>
                                <p>1- Click on « Faire un retrait », </p>
                                <p>2- select « Vers un autre compte »</p>',
    'withdrawal-2-desc-2' => '<p>3- fill in fields </p>
                                <ul>
                                    <li>Compte: Select one of your accounts</li>
                                    <li>Nom complet: your name</li>
                                    <li>Opérateur : MTN Cameroon or Orange Cameroon</li>
                                    <li>Nom complet du récepteur: your beneficiary\'s name</li>
                                    <li>Téléphone récepteur : Recipient\'s phone number</li>
                                    <li>Montant : amount to withdraw from your bank account to mobile money account</li>
                                    <li>Code secret : to secure the transaction. It should not be disclosed to anyone</li>
                                </ul>',
    'withdrawal-2-desc-3' => '<p>After filling the fields</p>
                                <p>4- Click on « Procéder »</p>
                                <p>The operation is successfully registered</p>
                                <p>5- Click on « ok »</p>
                                <p>6- the operation is registered with the “Unconfirmed” status waiting validation from the Administration</p>
                                <p>7- Click on the symbol to return to the home page.</p>',
    'transfer-desc-1' => '<p>The "transfer to an account" feature allows you to transfer money from your bank account to another bank account.</p>
                                <p>Bank accounts must be domiciled in the same financial institution</p>
                                <p>To access this feature, please follow the following steps:</p>
                                <p>1- Click on « Faire un transfert »,</p>
                                <p>You are redirected to the transfer page</p>',
    'transfer-desc-2' => '<p>2- fill in the fields</p>
                                <ul>
                                    <li>Compte: Select one of your accounts</li>
                                    <li>Nom complet: your name</li>
                                    <li>Nom(s) et prénom(s) complet: your beneficiary\'s name</li>
                                    <li>Numéro de compte récepteur : Recipient\'s account number</li>
                                    <li>Montant: Amount to transfer</li>
                                    <li>Code secret : to secure the transaction. It should not be disclosed to anyone</li>
                                </ul>
                                <p>After filling the fields</p>
                                <p>3- Click on « Procéder »</p>
                                <p>The operation is successfully registered</p>',
    'transfer-desc-3' => '<p>The operation is successfully registered</p>
                                <p>The operation is successfully registered</p>
                                <p>5- Click on « ok »</p>
                                <p>6- the operation is registered with the “Unconfirmed” status waiting validation from the Administration</p>
                                <p>7- Click on the symbol to return to the home page</p>',
    'transfer-desc-4' => '<p>The "Agency Withdrawal" feature allows you to transfer money to withdraw it from an MFI/Banks agency.</p>
                                <p>To access this feature, please follow the following steps:</p>
                                <p>1- Click on « withdrawal in agency »,</p>
                                <p>You are redirected to the transfer page</p>',
    'transfer-desc-5' => '<p>2- fill in the fields</p>
                                <ul>
                                    <li>Account: Select one of your accounts</li>
                                    <li>Recipient\'s full name and first name</li>
                                    <li>Opérateur : MTN Cameroun or Orange Cameroun </li>
                                    <li>téléphone: Recipient\'s phone number</li>
                                    <li>Montant: Amount to be transferred</li>
                                    <li>Mot de passe : your secret code to communicate to your beneficiary  </li>
                                    <li>Code secret : to secure the transaction. It should not be disclosed to anyone</li>
                                    <p>After filling the fields</p>
                                    <p>3- Click on « Procéder »</p>
                                    <li>The operation is successfully registered</li>
                                </ul>
                                <p>You have the option to send the transfer details to the recipient</p>',
    'transfer-desc-6' => '<p>After clicking "Proceed" you have the option to send the transfer details to the recipient</p>
                                <ul>
                                    <li>Click on « Non ça va » If you don\'t want to notify the recipient of the transfer</li>
                                    <li>Click on « Oui  » to notify the beneficiary</li>
                                    <li>By clicking "Yes," you should choose the app by which you would like to notify the beneficiary</li>
                                </ul>',
    'transfer-desc-7' => '<p>The operation is successfully registered</p>
                                <p>The operation is successfully registered</p>
                                <p>5- Click on « ok »</p>
                                <p>6- the operation is registered with the “Unconfirmed” status waiting validation from the Administration</p>
                                <p>7- Click on the symbol to return to the home page</p>',
    'transaction-desc-1' => '<p>To view the history of transactions in the mobile app, please follow the following steps:</p>
                                <p>1- Click on the Menu symbol</p>
                                <p>2- page du menu</p>
                                <p>You have the history of:</p>
                                <p>3. Completed transactions : Transactions validated by MFI/bank</p>
                                <p>4. Pending transactions : Transactions in validation expectations</p>
                                <p>5. Failed transactions : Transactions rejetées</p>',
    'transaction-desc-2' => '<p>To view the history of completed transactions, please follow the following steps: </p>
                                <p>1- Click on the Menu symbol</p>
                                <p>2- Click ok « Completed transactions »</p>
                                <p>You are redirected to the validated transactions page</p>',
    'transaction-desc-3' => '<p>Validated Transactions Page</p>
                                <p>1- Click on the symbol to view the menu</p>
                                <p>2- Click on the symbol to select another account to show its history.</p>
                                <p>3- Click on the symbol to return to the home page</p>
                                <p>4- Click on the symbol to see details of the operation.</p>',
    'profil-desc-1' => '<p>After downloading the app from the Play store, please follow the following steps to connect to the mobile app:</p>
                                <p>1- Go to your phone\'s menu and open the Becon\'Bank app</p>
                                <p>2- Enter your email address or phone number</p>
                                <p>3- Enter your password</p>
                                <p>4- click "Log in"</p>
                                <p>You are redirected to the home page of the mobile app</p>',
    'profil-desc-2' => '<p>To view your profile, you have 02 possibilities:</p>
                                <p><u>1ère possibilité :</u></p>
                                <p>1- Click on the Menu symbol</p>
                                <p>2- Click on "My profile"</p>
                                <p><u>2ème possibilité: </u></p>
                                <p>3- Click on "My Profile"</p>
                                <p>You are redirected to the Profile Access Page</p>',
    'profil-desc-3' => '<p>Profile access page</p>
                        <p>To change the profile, please change the information at your convenience</p>
                        <p>1- then click « Validate »</p>
                        <p>Your profile is successfully updated</p>
                        <p>2-Click ok</p>',
    'profil-desc-4' => '<p>To change your account password, follow these steps:</p>
                            <p>1- Cliquer sur « Password »</p>
                            <p>fill in the fields</p>
                            <p>2- click on “Valider”</p>',
    'profil-desc-5' => '<p>Profile access page</p>
                            <p>1- Click on « Code secret »</p>
                            <p>Fill in the fields</p>
                            <p>2- Click on « Valider »</p>
                            <p>Successfully amended secret code</p>',
    'profil-desc-6' => '<p>To get out of the app, please follow the following steps: </p>
                            <p>1- Click on the Menu symbol</p>
                            <p>2- Click on "Exit app"</p>
                            <p>3- Click on « Yes »</p>
                            <p>The "Exit app" feature lets you leave the app</p>',
    'profil-desc-7' => '<div class="" style=" ">
                            <p>To log out, please follow the following steps: </p>
                            <p>1- Click on the Menu symbol</p>
                            <p>2- Click on « Logout »</p>
                            <p>You are redirected to the login page</p>',

];
