<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Pagination Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the paginator library to build
    | the simple pagination links. You are free to change them to anything
    | you want to customize your views to better match your application.
    |
    */

    'home' => 'Home',
    'title' => 'Getting started with your',
    'title-2' => 'plateform',
    'about-us' => 'About us',
    'about-us-1' => 'Help',
    'about-us-2' => 'About-us',
    'about-us-3' => 'Web features',
    'about-us-4' => 'Mobile features',
    'parteners' => 'Partners',
    'contact' => "Contacts",
    'emf-bank' => "You are a MFI / Banks",
    'sign-in' => "Sign in",
    'sign-out' => "Register",
    'copyrights' => 'All righs reserved',
    'general-condition' => 'General Condition',
    'privacy-policy' => 'Privacy Policy',
    'legal-notice' => 'Legal notice',
    'faq' => 'Frequently asked questions',
    'label' => 'Sign up for our newsletter and stay connected:',
];
