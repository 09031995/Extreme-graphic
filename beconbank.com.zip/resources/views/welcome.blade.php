@extends('frontend.layouts.app')
@section('description')
<meta name="description" content="" />
@endsection
@section('keywords')
<meta name="keywords" content="" />
@endsection
@section('title', 'Mobile Banking')
@section('content')

<div role="main" class="main">
                <div class="slider-container rev_slider_wrapper" style="height: 100vh;">
                    <div id="revolutionSlider" class="slider rev_slider" data-version="5.4.8" data-plugin-revolution-slider data-plugin-options="{'sliderLayout': 'fullscreen', 'delay': 9000, 'gridwidth': 1170, 'gridheight': 700, 'disableProgressBar': 'on', 'responsiveLevels': [4096,1200,992,500], 'parallax': { 'type': 'scroll', 'origo': 'enterpoint', 'speed': 1000, 'levels': [2,3,4,5,6,7,8,9,12,50], 'disable_onmobile': 'on' }}">
                        <ul>
                            <li class="slide-overlay" data-transition="fade">
                                <img src="{{ asset('img/slides/slide2.png') }}"
                                    alt=""
                                    data-bgposition="center center" 
                                    data-bgfit="cover" 
                                    data-bgrepeat="no-repeat" 
                                    class="rev-slidebg">
                                
                                <div class="tp-caption"
                                    data-x="center" data-hoffset="['-165','-165','-165','-215']"
                                    data-y="center" data-voffset="['-110','-110','-110','-135']"
                                    data-start="1000"
                                    data-transform_in="x:[-300%];opacity:0;s:500;"
                                    data-transform_idle="opacity:0.2;s:500;"><img src="{{ asset('img/slides/slide-title-border.png') }}" alt="" style="display: none;"></div>

                                    <h1 class="tp-caption font-weight-extra-bold hidden-xs text-color-light negative-ls-2"
                                    data-frames='[{"delay":1000,"speed":2000,"frame":"0","from":"sX:1.5;opacity:0;fb:20px;","to":"o:1;fb:0;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;fb:0;","ease":"Power3.easeInOut"}]'
                                    data-x="center"
                                    data-y="center" data-voffset="['-60','-60','-60','-85']"
                                    data-fontsize="['50','50','50','90']"
                                    data-lineheight="['55','55','55','95']">{{__('home.slide-1')}}</h1>

                                    <h1 class="tp-caption font-weight-extra-bold text-color-light visible-xs negative-ls-2 text-center"
                                        data-frames='[{"delay":1000,"speed":2000,"frame":"0","from":"sX:1.5;opacity:0;fb:20px;","to":"o:1;fb:0;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;fb:0;","ease":"Power3.easeInOut"}]'
                                        data-x="center"
                                        data-y="center" data-voffset="['-60','-60','-60','-85']"
                                        data-fontsize="['50','50','50','90']"
                                        data-lineheight="['55','55','55','95']">{{__('home.text-1')}}<br>{{__('home.text-2')}}</h1>
                                
                            </li>
                        </ul>
                    </div>
                </div>

                <div class="container py-4">
                    <div class="row pt-4 mt-5">
                        <div class="col-lg-12">
                            <h2 class="font-weight-bold text-color-primary text-center text-7 mb-3">{{__('home.main-features')}}</h2>
                        </div>
                        <div class="col">
                            <div class="row pt-2 clearfix">
                                <div class="col-lg-6">
                                    <div class="feature-box feature-box-style-2 reverse appear-animation" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="200">
                                        <div class="feature-box-icon">
                                            <i class="icon-clock icons text-color-primary"></i>
                                        </div>
                                        <div class="feature-box-info">
                                            <h4 class="mb-2">{{__('home.feature-1')}}</h4>
                                            <p class="mb-4">{{__('home.feature-1-desc')}}.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="feature-box feature-box-style-2 appear-animation" data-appear-animation="fadeInLeftShorter" data-appear-animation-delay="200">
                                        <div class="feature-box-icon">
                                            <i class="icon-list icons text-color-primary"></i>
                                        </div>
                                        <div class="feature-box-info">
                                            <h4 class="mb-2">{{__('home.feature-2')}}</h4>
                                            <p class="mb-4">{{__('home.feature-2-desc')}}.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="feature-box feature-box-style-2 reverse appear-animation" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="400">
                                        <div class="feature-box-icon">
                                            <i class="icon-wallet icons text-color-primary"></i>
                                        </div>
                                        <div class="feature-box-info">
                                            <h4 class="mb-2">{{__('home.feature-3')}}</h4>
                                            <p class="mb-4">{{__('home.feature-3-desc')}}.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="feature-box feature-box-style-2 appear-animation" data-appear-animation="fadeInLeftShorter" data-appear-animation-delay="400">
                                        <div class="feature-box-icon">
                                            <i class="icon-location-pin icons text-color-primary"></i>
                                        </div>
                                        <div class="feature-box-info">
                                            <h4 class="mb-2">{{__('home.feature-4')}}</h4>
                                            <p class="mb-4">{{__('home.feature-4-desc')}}.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="feature-box feature-box-style-2 reverse appear-animation" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="400">
                                        <div class="feature-box-icon">
                                            <i class="icon-refresh icons text-color-primary"></i>
                                        </div>
                                        <div class="feature-box-info">
                                            <h4 class="mb-2">{{__('home.feature-5')}}</h4>
                                            <p class="mb-4">{{__('home.feature-5-desc')}}.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="feature-box feature-box-style-2 appear-animation" data-appear-animation="fadeInLeftShorter" data-appear-animation-delay="400">
                                        <div class="feature-box-icon">
                                            <i class="icon-target icons text-color-primary"></i>
                                        </div>
                                        <div class="feature-box-info">
                                            <h4 class="mb-2">{{__('home.feature-6')}}</h4>
                                            <p class="mb-4">{{__('home.feature-6-desc')}}.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <section class="section section-secondary border-0 py-0 m-0 appear-animation" data-appear-animation="fadeIn">
                    <div class="container">
                        <div class="row align-items-center justify-content-center justify-content-lg-between pb-5 pb-lg-0">
                            <div class="col-lg-6 order-2 order-lg-1 pt-4 pt-lg-0 pb-5 pb-lg-0 mt-5 mt-lg-0 appear-animation" data-appear-animation="fadeInRightShorter" data-appear-animation-delay="200">
                                <h2 class="font-weight-bold text-color-light text-7 mb-2">{{__('home.beconbank-advantages')}}</h2>
                                <div class="feature-box feature-box-style-2 appear-animation" data-appear-animation="fadeInLeftShorter">
                                    <div class="feature-box-icon">
                                        <i class="icon-shield icons text-color-light"></i>
                                    </div>
                                    <div class="feature-box-info">
                                        <span class="text-color-light">{{__('home.advantage-1')}}</span>
                                    </div>
                                </div>
                                <div class="feature-box feature-box-style-2  appear-animation" data-appear-animation="fadeInLeftShorter">
                                    <div class="feature-box-icon">
                                        <i class="icon-user-following icons text-color-light"></i>
                                    </div>
                                    <div class="feature-box-info">
                                        <span class="text-color-light">{{__('home.advantage-2')}}</span>
                                    </div>
                                </div>
                                <div class="feature-box feature-box-style-2 appear-animation" data-appear-animation="fadeInLeftShorter">
                                    <div class="feature-box-icon">
                                        <i class="icon-clock icons text-color-light"></i>
                                    </div>
                                    <div class="feature-box-info">
                                        <span class="text-color-light">{{__('home.advantage-3')}}</span>
                                    </div>
                                </div>
                                <div class="feature-box feature-box-style-2  appear-animation" data-appear-animation="fadeInLeftShorter">
                                    <div class="feature-box-icon">
                                        <i class="icon-envelope-letter icons text-color-light"></i>
                                    </div>
                                    <div class="feature-box-info">
                                        <span class="text-color-light">{{__('home.advantage-4')}}</span>
                                    </div>
                                </div>
                                <div class="feature-box feature-box-style-2 appear-animation" data-appear-animation="fadeInLeftShorter">
                                    <div class="feature-box-icon">
                                        <i class="icon-layers icons text-color-light"></i>
                                    </div>
                                    <div class="feature-box-info">
                                        <span class="text-color-light">{{__('home.advantage-5')}}</span>
                                    </div>
                                </div>
                                <div class="feature-box feature-box-style-2  appear-animation" data-appear-animation="fadeInLeftShorter">
                                    <div class="feature-box-icon">
                                        <i class="icon-eye icons text-color-light"></i>
                                    </div>
                                    <div class="feature-box-info">
                                        <span class="text-color-light">{{__('home.advantage-6')}}</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-9 offset-lg-1 col-lg-5 order-1 order-lg-2 scale-2">
                                <img class="img-fluid box-shadow-3 my-2 border-radius" data-appear-animation="fadeInLeftShorter" src="{{ asset('img/beconbank2.png') }}" style="background-color: #eff3f9;" alt="">
                            </div>
                        </div>
                    </div>
                </section>

                <div class="container">
                    <div class="row py-5 my-5">
                        <div class="col">
                    
                            <div class="owl-carousel owl-theme mb-0" data-plugin-options="{'responsive': {'0': {'items': 1}, '476': {'items': 1}, '768': {'items': 5}, '992': {'items': 7}, '1200': {'items': 7}}, 'autoplay': true, 'autoplayTimeout': 3000, 'dots': false}">
                                <div>
                                    <img class="img-fluid opacity-2" src="{{ asset('img/logos/logo-mobility-cloud-fr.png') }}" alt="" style="margin-left: 34px;">
                                </div>
                                <div>
                                    <img class="img-fluid opacity-2" src="{{ asset('img/logos/wouri-tv.png') }}" alt="" style="width: 60px;margin-left: 71px;margin-right: 15px;">
                                </div>
                                <div>
                                    <img class="img-fluid opacity-2" src="{{ asset('img/logos/logo-inimov-valide.png') }}" alt="">
                                </div>
                                <div>
                                    <img class="img-fluid opacity-2" src="{{ asset('img/logos/logo-mobility-cloud-fr.png') }}" alt="" style="margin-left: 34px;">
                                </div>
                                <div>
                                    <img class="img-fluid opacity-2" src="{{ asset('img/logos/wouri-tv.png') }}" alt="" style="width: 60px;margin-left: 71px;margin-right: 15px;">
                                </div>
                                <div>
                                    <img class="img-fluid opacity-2" src="{{ asset('img/logos/logo-inimov-valide.png') }}" alt="">
                                </div>
                                <div>
                                    <img class="img-fluid opacity-2" src="{{ asset('img/logos/logo-mobility-cloud-fr.png') }}" alt="" style="margin-left: 34px;">
                                </div>
                                <div>
                                    <img class="img-fluid opacity-2" src="{{ asset('img/logos/wouri-tv.png') }}" alt="" style="width: 60px;margin-left: 71px;margin-right: 15px;">
                                </div>
                                <div>
                                    <img class="img-fluid opacity-2" src="{{ asset('img/logos/logo-inimov-valide.png') }}" alt="">
                                </div>
                            </div>
                            
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <h2 class="font-weight-bold text-color-primary text-center text-7 mb-4">{{__('home.how-it-works')}}</h2>
                        </div>
                    </div>


                    <div class="row mb-5 pb-3">
                        
                        <div class="col-md-6 col-lg-4 mb-5 mb-lg-0 appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="200">
                            <div class="card flip-card text-center rounded-0">
                                <div class="flip-front p-5">
                                    <div class="flip-content my-4">
                                        <strong class="font-weight-extra-bold text-color-primary line-height-1 text-13 mb-3 d-inline-block">01</strong>
                                        <p>{{__('home.how-it-works-1')}}</p> 
                                    </div>
                                </div>
                                <div class="flip-back d-flex align-items-center p-5" style="background-image: url({{ asset('img/conseiller.jpg') }}); background-size: cover; background-position: center;">
                                    <div class="flip-content my-4">
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-4 mb-5 mb-lg-0 appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="400">

                            <div class="card flip-card flip-card-vertical text-center rounded-0">
                                <div class="flip-front p-5">
                                    <div class="flip-content my-4">
                                        <strong class="font-weight-extra-bold text-color-primary line-height-1 text-13 mb-3 d-inline-block">02</strong>
                                        <p> {{__('home.how-it-works-2')}}<br>&nbsp;</p> 
                                    </div>
                                </div>
                                <div class="flip-back d-flex align-items-center p-5" style="background-image: url({{ asset('img/connexion.jpg') }}); background-size: cover; background-position: center;">
                                    <div class="flip-content my-4">
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-4 mb-5 mb-lg-0 appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="600">

                            <div class="card flip-card flip-card-3d text-center rounded-0">
                                <div class="flip-front p-5">
                                    <div class="flip-content my-4">
                                        <strong class="font-weight-extra-bold text-color-primary line-height-1 text-13 mb-3 d-inline-block">03</strong>
                                        <p>{{__('home.how-it-works-3')}} <br>&nbsp; <br>&nbsp; </p>
                                    </div>
                                </div>
                                <div class="flip-back d-flex align-items-center p-5" style="background-image: url({{ asset('img/reseau.jpg') }}); background-size: cover; background-position: center;">
                                    <div class="flip-content my-4">
                                        
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

            </div>

@endsection
