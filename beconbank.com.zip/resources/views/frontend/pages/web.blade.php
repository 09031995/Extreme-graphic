@extends('frontend.layouts.app')
@section('description')
<meta name="description" content="" />
@endsection
@section('keywords')
<meta name="keywords" content="" />
@endsection
@section('title', 'Aide Utilisateur')
@section('content')

<section class="page-header page-header-modern page-header-background page-header-background-pattern page-header-background-sm overlay overlay-color-dark overlay-show overlay-op-5" style="background-image: url(img/patterns/wild_oliva.png);">
					<div class="container">
						<div class="row">
							<div class="col-md-12 align-self-center p-static order-2 text-center">
								<h1> {{__('nav.title')}} <strong>{{__('nav.title-2')}}</strong></h1>
							</div>
							<div class="col-md-12 align-self-center order-1">
								<ul class="breadcrumb breadcrumb-light d-block text-center">
									<li><a href="{{route('home')}}">{{__('nav.home')}}</a></li>
									<li><a href="#"> {{__('nav.about-us')}}</a></li>
									<li class="active">{{__('nav.about-us-1')}}</li>
								</ul>
							</div>
						</div>
					</div>
				</section>
	<section class="container py-2">
		<div class="row mt-5">
						<div class="col">
							<div class="row">
								<div class="col-lg-3">
									<div class="tabs tabs-vertical tabs-right tabs-navigation tabs-navigation-simple">
										<ul class="nav nav-tabs col-sm-3">
                                            <li class="nav-item active" style="list-style: none;">
                                                <a class="nav-link" href="#tabsNavigationVertSimple1-1" data-toggle="tab">{{__('web.cash-deposit-1')}}</a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" href="#tabsNavigationVertSimple1-2" data-toggle="tab">{{__('web.cash-deposit-2')}}</a>
                                            </li>
                                            <li  class="nav-item">
                                                <a class="nav-link" href="#tabsNavigationVertSimple2-1" data-toggle="tab">{{__('web.cash-withdrawal-1')}}</a>
                                            </li>
                                            <li  class="nav-item">
                                                <a class="nav-link" href="#tabsNavigationVertSimple2-2" data-toggle="tab">{{__('web.cash-withdrawal-2')}}</a>
                                            </li>
											<li class="nav-item">
												<a class="nav-link" href="#tabsNavigationVertSimple3-1" data-toggle="tab">{{__('web.cash-transfer-1')}}</a>
											</li>
											<li class="nav-item">
												<a class="nav-link" href="#tabsNavigationVertSimple3-2" data-toggle="tab">{{__('web.cash-transfer-2')}}</a>
											</li>
											<li class="nav-item">
												<a class="nav-link" href="#tabsNavigationVertSimple5" data-toggle="tab">{{__('web.transaction-management')}}</a>
											</li>
											<li class="nav-item">
												<a class="nav-link" href="#tabsNavigationVertSimple4" data-toggle="tab">{{__('web.customer-setup')}}</a>
											</li>
										</ul>
									</div>
								</div>
								<div class="col-lg-9">
									<!--<div class="tab-pane tab-pane-navigation active" id="tabsNavigationVertSimple1">
										<h4>{{__('help.cash-deposit')}}</h4>
										@if(session('applocale')=="fr") 
											<iframe src="https://docs.google.com/presentation/d/e/2PACX-1vQTPa1iUPE9N9Wc7pj0w-D6rnWM6-jK6BVCbA1to_t6xFizDUWCtVHOd_IV1tu-mg/embed?start=false&loop=false&delayms=3000" frameborder="0" width="850" height="667" allowfullscreen="true" mozallowfullscreen="true" webkitallowfullscreen="true"></iframe>
										@else
											<iframe src="https://docs.google.com/presentation/d/e/2PACX-1vQjmZsnPzJG64Uza0Tt__kywv9UMCBF_KvfHj1MHjdstV576c_T7el-H6OG10EA-A/embed?start=false&loop=false&delayms=3000" frameborder="0" width="850" height="667" allowfullscreen="true" mozallowfullscreen="true" webkitallowfullscreen="true"></iframe></iframe>
										@endif
									</div>
									<div class="tab-pane tab-pane-navigation" id="tabsNavigationVertSimple2">
										<h4>{{__('help.cash-withdrawal')}}</h4>
										@if(session('applocale')=="fr") 
											<iframe src="https://docs.google.com/presentation/d/e/2PACX-1vRkiqk0kU4YmLNhYD-RhOzdMsFnnNGZ7tXnVQHvTCIjSDe-VHErNnnHRonLTZvy-Q/embed?start=false&loop=false&delayms=3000" frameborder="0" width="850" height="667" allowfullscreen="true" mozallowfullscreen="true" webkitallowfullscreen="true"></iframe>
										@else
											<iframe src="https://docs.google.com/presentation/d/e/2PACX-1vSz6zRoseGt6ZFIIATa5gonIaPLQhfb8LqFDeeuhVwYALcFwfUUmFhdlVByYFTWMw/embed?start=false&loop=false&delayms=3000" frameborder="0" width="850" height="667" allowfullscreen="true" mozallowfullscreen="true" webkitallowfullscreen="true"></iframe></iframe>
										@endif
									</div>
									<div class="tab-pane tab-pane-navigation" id="tabsNavigationVertSimple3">
										<h4>{{__('help.cash-transfer')}}</h4>
										@if(session('applocale')=="fr") 
											<iframe src="https://docs.google.com/presentation/d/e/2PACX-1vT0AE-oSNxwjTVkHjDOmDzQJb0MzO85hHZdIFXQGUWew6O9iHV_5ag_k8VToCstSw/embed?start=false&loop=false&delayms=3000" frameborder="0" width="850" height="667" allowfullscreen="true" mozallowfullscreen="true" webkitallowfullscreen="true"></iframe>
										@else
											<iframe src="https://docs.google.com/presentation/d/e/2PACX-1vQkEkZ2rw3gqmJwW9Ogx2g1P-JrwmKmaK36Jy_ZxTDfAEkGhCrtbPINMsyZjgieJA/embed?start=false&loop=false&delayms=3000" frameborder="0" width="850" height="667" allowfullscreen="true" mozallowfullscreen="true" webkitallowfullscreen="true"></iframe></iframe>
										@endif
									</div>
									<div class="tab-pane tab-pane-navigation" id="tabsNavigationVertSimple4">
										<h4>{{__('help.customer-setup')}}</h4>
										@if(session('applocale')=="fr") 
											<iframe src="https://docs.google.com/presentation/d/e/2PACX-1vR2ssXMAPAFSd3CsZvyO17W-k36sZIfsrwJK7Rd1anrR5_QLjTAPYxvHUuniG-N1A/embed?start=false&loop=false&delayms=3000" frameborder="0" width="850" height="667" allowfullscreen="true" mozallowfullscreen="true" webkitallowfullscreen="true"></iframe>
										@else
											<iframe src="https://docs.google.com/presentation/d/e/2PACX-1vT2ItntNjGBdm5KNRnZHTdP-xcPWVv6CvbROvHYJesfBO_N0RDQbmli5SY6K95kqg/embed?start=false&loop=false&delayms=3000" frameborder="0" width="850" height="667" allowfullscreen="true" mozallowfullscreen="true" webkitallowfullscreen="true"></iframe></iframe>
										@endif
									</div>
									<div class="tab-pane tab-pane-navigation" id="tabsNavigationVertSimple5">
										<h4>{{__('help.transaction-management')}}</h4>
										@if(session('applocale')=="fr") 
											<iframe src="https://docs.google.com/presentation/d/e/2PACX-1vSxJ1ac9sEcvqTN6yq6lXfIGLNzjn9mp8qXQ1kKBx9Ux4GPWMg18SF4ecazbzgWhw/embed?start=false&loop=false&delayms=3000" frameborder="0" width="850" height="667" allowfullscreen="true" mozallowfullscreen="true" webkitallowfullscreen="true"></iframe>
										@else
											<iframe src="https://docs.google.com/presentation/d/e/2PACX-1vTwM3YlzitJcs15GgKvfhyKRfqiNeTd36eOfnLSCd0DOuJI1eT9OWnU-f38ZdBCTQ/embed?start=false&loop=false&delayms=3000" frameborder="0" width="850" height="667" allowfullscreen="true" mozallowfullscreen="true" webkitallowfullscreen="true"></iframe></iframe>
										@endif
									</div>-->
									<div class="tab-pane tab-pane-navigation active" id="tabsNavigationVertSimple1-1">
										<h4>{{__('web.cash-deposit')}} {{__('web.deposit-operator-1')}}</h4>
										<div class="row py-2">

											<div class="">
												<img src="{{ asset('img/aide/web/depot/1_'.session('applocale').'.png')}}" style="width: 100%;">
											</div>
											<div class="" style=" ">{!! __('web.deposit-operator-1-desc-1')!!}</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/depot/2_'.session('applocale').'.png') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">{!!__('web.deposit-operator-1-desc-2')!!}</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/depot/3_'.session('applocale').'.png') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">{!!__('web.deposit-operator-1-desc-3')!!}</div>
										</div>
									</div>
									<div class="tab-pane tab-pane-navigation" id="tabsNavigationVertSimple1-2">
										<h4>{{__('web.cash-deposit')}} {{__('web.deposit-operator-2')}}</h4>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/depot/4_'.session('applocale').'.png') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">{!!__('web.deposit-operator-2-desc-1')!!}</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/depot/5_'.session('applocale').'.png') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">{!!__('web.deposit-operator-2-desc-2')!!}</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/depot/6_'.session('applocale').'.png') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p>{!!__('web.deposit-operator-2-desc-3')!!}</p>
											</div>
										</div>
									<!--<div class="row py-2">
											<div class="col-lg-7">
												<img src="{{ asset('img/aide/web/depot/7.png') }}" style="width: 100%;">
											</div>
											<div class="col-lg-5" style=" ">
												<p>6- Vous recevrez un message de votre Opérateur téléphonique dans votre téléphone</p>
												<p>7- et un mail de Becon’Bank</p>
												<p>8- La transaction passe au statut « confirmed »</p>
											</div>
										</div>-->
									</div>
									<div class="tab-pane tab-pane-navigation" id="tabsNavigationVertSimple2-1">
										<h4>{{__('web.cash-withdrawal')}}</h4>
										<!--<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/retrait/2.png') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p>Il existe deux types de retrait :</p>
												<ul>
													<li>Retrait d’argent vers mon numéro de téléphone</li>
													<li>Retrait d’argent vers un autre numéro de téléphone</li>
												</ul>
											</div>
										</div>-->
										<div class="row py-2">
											<h5>{!!__('web.cash-withdrawal-1')!!}</h5>
											<div class="">
												<img src="{{ asset('img/aide/web/retrait/1_'.session('applocale').'.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">{!!__('web.withdrawal-1-desc-1')!!}</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/retrait/2_'.session('applocale').'.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">{!!__('web.withdrawal-1-desc-2')!!}</div>
										</div>
									</div>
									<div class="tab-pane tab-pane-navigation" id="tabsNavigationVertSimple2-2">
										<h4>{{__('web.cash-withdrawal')}}</h4>
										<div class="row py-2">
											<h5>{{__('web.cash-withdrawal-2')}}</h5>
											<div class="">
												<img src="{{ asset('img/aide/web/retrait/3_'.session('applocale').'.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">{!!__('web.withdrawal-2-desc-1')!!}</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/retrait/4_'.session('applocale').'.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">{!!__('web.withdrawal-2-desc-2')!!}</div>
										</div>
									</div>
									<div class="tab-pane tab-pane-navigation " id="tabsNavigationVertSimple3-1">
										<h4>{{__('web.cash-transfer-1')}}</h4>
										<!--<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/Transfert/2.png') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p></p>
											</div>
										</div>-->
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/Transfert/1_'.session('applocale').'.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">{!!__('web.transfer-desc-1')!!}</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/Transfert/2_'.session('applocale').'.png') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">{!!__('web.transfer-desc-2')!!}</div>
										</div>
									</div>
									<div class="tab-pane tab-pane-navigation " id="tabsNavigationVertSimple3-2">
										<h4>{{__('help.cash-transfer-2')}}</h4>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/Transfert/3_'.session('applocale').'.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">{!!__('web.transfer-desc-3')!!}</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/Transfert/4_'.session('applocale').'.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">{!!__('web.transfer-desc-4')!!}</div>
										</div>
										<!--<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/Transfert/5.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p>5- remplir les champs</p>
												<p>Numéro de bordereau: à communiquer à votre bénéficiaire</p>
												<p>Choix du compte: choisir l’un de vos comptes avec lequel vous souhaitez effectuer la transaction</p>
												<p>Nom(s) et prénom(s): le nom complet de la personne à qui vous envoyez de l’argent</p>
												<p>Numéro téléphone: numéro de téléphone du destinataire</p>
												<p>Montant : le montant que vous souhaitez envoyer</p>
												<p>Code secret: votre code secret à communiquer à votre bénéficiaire</p>
												<p>6- cliquer sur « valider le transfert »</p>
												<p>7- l’opération passe au statut « unconfirmed » pour validation par l’EMF.</p>
											</div>
										</div>-->
									</div>
									<div class="tab-pane tab-pane-navigation" id="tabsNavigationVertSimple5">
										<h4>{{__('web.transaction-management')}}</h4>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/transaction/1_'.session('applocale').'.png') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">{!!__('web.transaction-desc-1')!!}</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/transaction/2_'.session('applocale').'.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">{!!__('web.transaction-desc-2')!!}</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/transaction/3_'.session('applocale').'.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">{!!__('web.transaction-desc-3')!!}</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/transaction/4_'.session('applocale').'.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">{!!__('web.transaction-desc-4')!!}</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/transaction/5_'.session('applocale').'.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p>{!!__('web.transaction-desc-5')!!}</p>
											</div>
										</div>
									</div>
									<div class="tab-pane tab-pane-navigation" id="tabsNavigationVertSimple4">
										<h4>{{__('web.customer-setup')}}</h4>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/profil/1_'.session('applocale').'.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">{!!__('web.profil-desc-1')!!}</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/profil/2_'.session('applocale').'.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">{!!__('web.profil-desc-2')!!}</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/profil/3_'.session('applocale').'.png') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p></p>
											</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/profil/4_'.session('applocale').'.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">{!!__('web.profil-desc-3')!!}</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/profil/5_'.session('applocale').'.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p></p>
											</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/profil/6_'.session('applocale').'.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">{!!__('web.profil-desc-4')!!}</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/profil/7_'.session('applocale').'.png') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">{!!__('web.profil-desc-5')!!}</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/profil/8_'.session('applocale').'.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p></p>
											</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/profil/9_'.session('applocale').'.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p></p>
											</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/profil/10_'.session('applocale').'.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">
												<p></p>
											</div>
										</div>
										<!--<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/profil/11_'.session('applocale').'.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">{!!__('help.profil-desc-6')!!}</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/profil/12_'.session('applocale').'.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">{!!__('help.profil-desc-7')!!}</div>
										</div>
										<div class="row py-2">
											<div class="">
												<img src="{{ asset('img/aide/web/profil/12_'.session('applocale').'.jpg') }}" style="width: 100%;">
											</div>
											<div class="" style=" ">{!!__('help.profil-desc-8')!!}</div>
										</div>-->
									</div>
								</div>
							</div>
						</div>
					</div>
	</section>
@endsection