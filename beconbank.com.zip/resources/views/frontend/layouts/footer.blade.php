<footer id="footer" class="mt-0 hidden-xs" style="padding-left: 144px;">
        <div class="container my-auto">
          <div class="row my-3">
            <form action="" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate">
              <table style="position: absolute;right: 162px;margin-top: -10px;">
                <th>
                  <td>
                    <div>
                      <label class="text-white">{{__('nav.label')}}</label>
                    </div>
                  </td>
                  <td>
                  <div class="form-group">
                    <input type="email" class="form-control"  aria-describedby="emailHelp" id="mce-EMAIL" placeholder="Enter email" style="height: 25px" required>
                  </div>
                  </td>
                  <td>
                    <div class="clear" style="">
                      <button type="submit" class="btn btn-outline-secondary" id="mc-embedded-subscribe" style="height: 25px; margin-top: -16px; background:#833b0b;  padding-top: 3px;  color: #f7f7f7;border-color: #833b0b;">
                        <i class="fa fa-envelope"></i>
                      </button>
                    </div>
                  </td>
                </th>
              </table>
            </form>
          </div>
          <div class="row my-3 py-3">
            <div class="col-md-3 col-lg-3 mb-5 mb-lg-0">
              <a href="#" class="text-4 text-transform-none text-color-light mb-4">© 2019 {{__('nav.copyrights')}}.</a>
            </div>
            <div class="col-md-3 col-lg-3 mb-5 mb-lg-0">
              <a href="#" class="text-4 text-transform-none text-color-light mb-4">{{__('nav.general-condition')}}</a>
            </div>
            <div class="col-md-3 col-lg-3 mb-5 mb-lg-0">
              <a href="#" class="text-4 text-transform-none text-color-light mb-4">{{__('nav.legal-notice')}}</a>
            </div>
            <div class="col-md-3 col-lg-3 mb-5 mb-lg-0">
              <a href="{{route('privacy')}}" class="text-4 text-transform-none text-color-light mb-4">{{__('nav.privacy-policy')}}</a>
            </div>
            <!--<div class="col-md-3 col-lg-3 mb-5 mb-lg-0">
              <a href="{{route('faq')}}" class="text-4 text-transform-none  text-color-light mb-4">{{__('nav.faq')}}</a>
            </div>-->
          </div>
        </div>
      </footer>

      <footer id="footer" class="mt-0 visible-xs" >
        <div class="container my-auto">
          <div class="row my-12">
            <form action="" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate">
              <table class="mx-4 text-center" >
                <th>
                  <tr>
                    <td>
                      <div>
                        <label class="text-white">{{__('nav.label')}}</label>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <div class="form-group">
                        <input type="email" class="form-control"  aria-describedby="emailHelp" id="mce-EMAIL" placeholder="Enter email" style="height: 25px" required>
                      </div>
                    </td>
                    <td>
                      <div class="clear" style="">
                        <button type="submit" class="btn btn-outline-secondary" id="mc-embedded-subscribe" style="height: 25px; margin-top: -16px; background:#833b0b;  padding-top: 3px;  color: #f7f7f7;border-color: #833b0b;">
                          <i class="fa fa-envelope"></i>
                        </button>
                      </div>
                    </td>
                  </tr>
                </th>
              </table>
            </form>
          </div>
          <div class="row-12" style="text-align: center">

              <div class="row">
                <div class="col-md-6 col-lg-1 mb-5 mb-lg-0" style="margin-bottom: 5px !important;">
                  <a href="#" class="text-4 text-transform-none text-color-light mb-4">© 2019 {{__('nav.copyrights')}}.</a>
                </div>
                <div class="col-md-6 col-lg-1 mb-5 mb-lg-0" style="margin-bottom: 5px !important;">
                  <a href="#" class="text-4 text-transform-none text-color-light mb-4">{{__('nav.general-condition')}}</a>
                </div>
              </div>


                <div class="row">
                  <div class="col-md-6 col-lg-3 mb-5 mb-lg-0" style="margin-bottom: 5px !important;">
                    <a href="#" class="text-4 text-transform-none text-color-light mb-4">{{__('nav.legal-notice')}}</a>
                  </div>
                  <div class="col-12" style="margin-bottom: 5px !important;">
                    <a href="{{route('privacy')}}" class="text-4 text-transform-none text-color-light mb-4">{{__('nav.privacy-policy')}}</a>
                  </div>
                </div>

          </div>


          <!--<div class="col-md-3 col-lg-3 mb-5 mb-lg-0">
                    <a href="{{route('faq')}}" class="text-4 text-transform-none  text-color-light mb-4">{{__('nav.faq')}}</a>
                  </div>-->

        </div>
      </footer>